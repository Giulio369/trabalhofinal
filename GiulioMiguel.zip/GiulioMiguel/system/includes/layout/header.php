
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema de Gerenciamento de Preventivas</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="icon" href="../img/iconNaxsys.png" type="image/png">
</head>
<body>
  <div class="fixed"> <!--Parte Fixa do Site-->
    <div class="naxsyspai"> <!--Logo Naxsys-->
	    <div class="naxsys">
        <a href="index.php">
	      <img id="naxsys" src="../img/naxsys.png" alt="Naxsys Brasil">
        </a>
	    </div> 
    </div>
        
    <nav> <!--Menus Fixos-->
        <a id="link-menu" href="index.php">TELA INICIAL</a>
        <a id="link-admin" href="adm.php">ADMINISTRAÇÃO</a>
    </nav>
  </div> <!--Fixed-->
