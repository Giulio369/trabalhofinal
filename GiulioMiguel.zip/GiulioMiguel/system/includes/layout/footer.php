</main>
<footer>


    </div>
    <div class="centralizar">
        <p>&copy; <?php
        date_default_timezone_set('America/Sao_Paulo');
         echo date("d/m/Y"); ?> - Naxsys Brasil </p>
        </div>
        <div class="centralizar">
    </div>
   
</footer>

</body>
</html>

<?php
   include('../php/OcultaAdm.php');
 ?>
