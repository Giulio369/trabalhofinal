<?php 
date_default_timezone_set('America/Sao_Paulo');

$ano = date('Y');
$mes = date('m');

if ($mes < 4) {
    $ciclo = 1;
} 
elseif ($mes > 3 && $mes < 7) {
    $ciclo = 2;
} 
elseif ($mes > 6 && $mes < 10)  {
    $ciclo = 3;
} 
else {
    $ciclo = 4;
} 
?>
