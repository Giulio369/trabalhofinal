$(document).ready(function() {
    // Inicializa o gráfico
    var ctx = document.getElementById('Televisoes').getContext('2d');
    var Cameras = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['TVs Realizadas', 'TVs Pendentes'], // Defina os labels iniciais
            datasets: [{
                data: [0, 0], // Inicialmente, os dados serão 0
                backgroundColor: ['#73CCC0', '#fff']
            }]
        },
        options: {
            title: { display: true, text: 'Porcentagem: 0.00%' },
            responsive: false,
            legend: {
                labels: {
                    fontFamily: 'Arial', // Define a fonte para o legend
                    fontSize: 14 // Define o tamanho da fonte para o legend
                }
            },
            plugins: {
                datalabels: {
                    font: {
                        family: 'Arial', // Define a fonte para os labels do gráfico
                        fontSize: 14 // Define o tamanho da fonte para os labels do gráfico
                    }
                }
            }
        }
    });

    const obterDados = () => {
        $.ajax({
            url: '../php/dashBoardTvs.php',
            method: 'GET',
            success: function(response) {
                var dados = response.split(",");
                var cadastradas = parseInt(dados[0]);
                var preventivas = parseInt(dados[1]);
                var cadastradas = cadastradas - preventivas; // Quantidade de câmeras realizadas
                var porcentagem = (preventivas / cadastradas) * 100;

                // Atualiza os dados do gráfico
                Cameras.data.datasets[0].data = [cadastradas, preventivas];
                Cameras.options.title.text = 'Porcentagem: ' + porcentagem.toFixed(2) + '%';
                Cameras.data.labels = ['TVs Realizadas (' + cadastradas + ')', 'TVs Pendentes (' + preventivas + ')']; // Atualiza os labels
                Cameras.update();
            },
            error: function(xhr, status, error) {
                console.error('Erro ao contar TVs e preventivas:', status, error);
            }
        });
    }

    // Atualiza o gráfico a cada 3 segundos
    let intervalo = setInterval(obterDados, 60000);
    obterDados();
});
