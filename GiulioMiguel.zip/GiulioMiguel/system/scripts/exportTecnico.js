function exportToExcel() {
    // Cria um objeto Date para obter a data e hora atuais
    var currentDate = new Date();
    
    // Formata a data e hora atual para incluir no nome do arquivo

    var formattedDate = currentDate.getDate() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getFullYear();
    var formattedTime = currentDate.getHours() + '.' + currentDate.getMinutes();

    // Define o nome do arquivo com a data e hora atuais
    var fileName = 'tecnicos(' + formattedDate + '_' + formattedTime + ').csv';

    // Cria um objeto XMLHttpRequest
    var xhr = new XMLHttpRequest();

    // Abre uma conexão com o script PHP que irá gerar o arquivo CSV
    xhr.open('GET', '../php/exportar.php', true);

    // Define o tipo de resposta como arraybuffer
    xhr.responseType = 'arraybuffer';

    // Configura o callback onload
    xhr.onload = function() {
        if (this.status === 200) {
            // Cria um blob a partir da resposta do servidor
            var blob = new Blob([this.response], { type: 'application/csv' });

            // Cria uma URL para o blob
            var url = window.URL.createObjectURL(blob);

            // Cria um link para download do arquivo
            var a = document.createElement('a');
            a.href = url;
            a.download = fileName;

            // Adiciona o link ao corpo do documento e simula um clique
            document.body.appendChild(a);
            a.click();

            // Remove o link do corpo do documento
            document.body.removeChild(a);
        }
    };

    // Envia a requisição
    xhr.send();
}
