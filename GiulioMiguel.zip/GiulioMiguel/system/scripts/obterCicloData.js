function obterCicloAtual() {
    const dataAtual = new Date();
    const ano = dataAtual.getFullYear();
    const mes = dataAtual.getMonth() + 1;

    let ciclo;

    if (mes < 4) {
        ciclo = 1;
    } else if (mes > 3 && mes < 7) {
        ciclo = 2;
    } else if (mes > 6 && mes < 10)  {
        ciclo = 3;
    } else {
        ciclo = 4;
    }

    return { ciclo, ano }; // Retorna um objeto contendo ciclo e ano
}

function diasRestantesNoCiclo() {
    const dataAtual = new Date();
    const ano = dataAtual.getFullYear();
    const mes = dataAtual.getMonth() + 1;

    let proximoMes;
    let proximoAno;

    if (mes < 4) {
        proximoMes = 4;
        proximoAno = ano;
    } else if (mes < 7) {
        proximoMes = 7;
        proximoAno = ano;
    } else if (mes < 10) {
        proximoMes = 10;
        proximoAno = ano;
    } else {
        proximoMes = 1;
        proximoAno = ano + 1; // Próximo ano
    }

    const inicioProximoCiclo = new Date(proximoAno, proximoMes - 1, 1); // Início do próximo ciclo
    const diffTime = inicioProximoCiclo - dataAtual; // Diferença em milissegundos
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // Diferença em dias

    return diffDays;
}


function atualizarCiclo() {
    const { ciclo, ano } = obterCicloAtual(); // Desestrutura o objeto retornado por obterCicloAtual()
    localStorage.setItem('ciclo', ciclo);

    // Calcula os dias restantes para o término do ciclo atual
    const diasRestantes = diasRestantesNoCiclo();
    
    // Atualiza o elemento HTML com o ciclo atual, o ano e os dias restantes
    document.getElementById('cicloAtual').innerText = `CICLO ${ciclo} de ${ano} \n Faltam ${diasRestantes} dias para terminar o ciclo`;
}
atualizarCiclo();
// Chama a função de atualização no carregamento da página
document.addEventListener("DOMContentLoaded", function() {
    atualizarCiclo();

    // Define um intervalo para atualizar o ciclo a cada 24 horas (86400000 milissegundos)
    setInterval(atualizarCiclo, 1000);
});
atualizarCiclo();
