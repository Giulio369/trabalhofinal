// Função para atualizar a data e hora a cada segundo
function atualizarDataHora() {
    // Obtém a data e hora atuais
    var dataAtual = new Date();

    // Extrai o dia, mês, ano, hora, minuto e segundo
    var dia = dataAtual.getDate();
    var mes = dataAtual.getMonth() + 1; // Mês é baseado em zero, então adicionamos 1
    var ano = dataAtual.getFullYear();
    var hora = dataAtual.getHours();
    var minuto = dataAtual.getMinutes();
    var segundo = dataAtual.getSeconds();

    // Formata a data e hora
    var dataFormatada = dia + '/' + mes + '/' + ano;
    var horaFormatada = hora + ':' + minuto + ':' + segundo;

    // Exibe a data e hora formatadas
    document.getElementById("dataAtual").textContent = "Data atual: " + dataFormatada;
    document.getElementById("horaAtual").textContent = "Hora atual: " + horaFormatada;
}

// Chama a função inicialmente para exibir a data e hora atual
atualizarDataHora();

// Atualiza a data e hora a cada segundo
setInterval(atualizarDataHora, 1000);
