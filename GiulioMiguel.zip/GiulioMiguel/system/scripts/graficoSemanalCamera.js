document.addEventListener('DOMContentLoaded', function() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var total_preventivas = parseInt(this.responseText);
            renderizarGrafico(total_preventivas);
        }
    };
    xhttp.open("GET", "dashBoardCameras.php", true);
    xhttp.send();
});

function renderizarGrafico(total_preventivas) {
    var ctx = document.getElementById('preventivasChart').getContext('2d');
    var preventivasChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Últimas 4 semanas'],
            datasets: [{
                label: 'Preventivas de Câmeras',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: [total_preventivas]
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
}
