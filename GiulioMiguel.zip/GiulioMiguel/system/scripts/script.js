$(document).ready(function() {
    // Inicializa o gráfico
    var ctx = document.getElementById('PreventivasSemanais').getContext('2d');
    var PreventivasSemanais = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [], // Labels das semanas
            datasets: [{
                label: 'Preventivas Realizadas',
                data: [], // Dados das preventivas por semana
                backgroundColor: 'rgba(115, 204, 192, 0.5)',
                borderColor: 'rgba(115, 204, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: false,
            legend: {
                display: true,
                labels: {
                    fontFamily: 'Arial',
                    fontSize: 14
                }
            },
            scales: {
                xAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });

    const obterDados = () => {
        $.ajax({
            url: '../php/dashBoardPreventivasSemanais.php',
            method: 'GET',
            success: function(response) {
                var dados = JSON.parse(response);
                var semanas = Object.keys(dados);
                var preventivas = Object.values(dados);

                // Atualiza os dados do gráfico
                PreventivasSemanais.data.labels = semanas;
                PreventivasSemanais.data.datasets[0].data = preventivas;
                PreventivasSemanais.update();
            },
            error: function(xhr, status, error) {
                console.error('Erro ao obter dados das preventivas semanais:', status, error);
            }
        });
    }

    // Atualiza o gráfico a cada 3 segundos
    let intervalo = setInterval(obterDados, 60000);
    obterDados();
});
