<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/preventivacameraverificar.php');
?>

  <main>
    <div class="titulopagina">
      <h2>Preventiva de Câmera</h2>
      <h2 style="color: red;">Preventiva não Realizada!</h2>
      <h2 style="color: red;">Câmera Inexistente!</h2>
    </div>

    <div class="centralizar"> 
    <form action="#" method="post">
      <div class="form-group">
        <label>Câmera</label>
        <input type="text" name="nome" required><br>
        <button type="submit">Próximo</button> 
    </div>
  </form>
</div>

    
    <div class="centralizar"> 
      <a href="iniciarpreventiva.php">
        <button>Voltar</button> 
      </a>
    </div>

  </main>
  
<?php include('../includes/layout/footer.php') ?>
</body>
</html>