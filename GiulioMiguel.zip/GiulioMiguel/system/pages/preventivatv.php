<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/preventivatv.php');
?>

  <main>
    <div class="titulopagina">
      <h2>Preventiva de TV</h2>
    </div>


<div class="centralizar"> <!--Criar Centralização e Personalização do FORMULARIO!!-->
  <form action="#" method="post">
    <div class="form-group">
      <label>Tela:</label> <input type="text" name="tela" required><br>
      <label>Controles:</label> <input type="text" name="controles" required><br>
      <label>Configuracao:</label> <input type="text" name="configuracao" required><br>
      <label>Cabos:</label> <input type="text" name="cabeamento" required><br>
      <label>Observação:</label> <input type="text" name="observacao" required><br>
      <button type="submit">Finalizar</button> 
    </div>
  </form>
</div>


    
    <div class="centralizar"> 
      <a href="iniciarpreventiva.php">
        <button>Voltar</button> 
      </a>
    </div>

  </main>
  
<?php include('../includes/layout/footer.php') ?>
</body>
</html>