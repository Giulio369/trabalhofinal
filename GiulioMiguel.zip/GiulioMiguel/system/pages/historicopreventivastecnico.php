<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>


        <main>
      <div class="titulopagina">
        <h2 style ="text-align: center; ">Historico de Preventivas</h2>
      </div>
       
      </div>

  <div class="centro">
    <div class="centralizar">
   
      <a href="HistoricoPreventivaTecnicoCam.php">
        <button>Preventivas de Câmera</button>
      </a>
    </div>

     
    <div class="centralizar">
      <a href="HistoricoPreventivaTecnicoTv.php">
        <button>Preventivas de TV</button>
      </a>
    </div>

     <div class="centralizar"> 
      <a href="index.php">
        <button>Voltar</button> 
      </a>
     </div>
    </div>

    <?php include('../includes/layout/footer.php') ?>
</body>
</html>