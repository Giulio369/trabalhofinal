<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>


        <main>
      <div class="titulopagina">
        <h2 style ="text-align: center; ">Escolha qual preventiva deseja realizar</h2>
      </div>
       
      </div>

  <div class="centro">
    <div class="centralizar">
   
      <a href="preventivacameraVerificar.php">
        <button>Câmera</button>
      </a>
    </div>

     
    <div class="centralizar">
      <a href="preventivatvVerificar.php">
        <button>TV</button>
      </a>
    </div>

     <div class="centralizar"> 
      <a href="index.php">
        <button>Voltar</button> 
      </a>
     </div>
    </div>

    <?php include('../includes/layout/footer.php') ?>
</body>
</html>