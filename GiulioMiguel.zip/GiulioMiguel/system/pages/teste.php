<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleção de Câmeras</title>
</head>
<body>
    <h1>Seleção de Câmeras</h1>
    <form method="post" action="processar_preventiva.php">
        <label for="cameraSelect">Selecione a câmera:</label>
        <select name="cameraSelect" id="cameraSelect">
            <?php
            
            $servername = "localhost";
            $username = "root";
            $password = "@admin";
            $dbname = "sgpn";
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Erro na conexão com o banco de dados: " . $conn->connect_error);
            }
        
            $sql = "SELECT ip, nome FROM camera";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row["ip"] . "'>" . $row["nome"] . "</option>";
                }
            } else {
                echo "<option value=''>Nenhuma câmera encontrada</option>";
            }
            $conn->close();
            ?>
        </select>
        <button type="submit">Adicionar Preventiva</button>
    </form>
</body>
</html>
