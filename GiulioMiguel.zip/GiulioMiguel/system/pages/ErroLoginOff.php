<?php 
include('../includes/layout/header.php');
?>

  <main>
    <div class="titulopagina">
      <h2>Erro! Você precisa estar logado para acessar esta página!</h2>
    </div>

    <div class="centralizar"> 
      <a href="Login.php">
        <button>Realizar Login</button> 
      </a>
    </div>

  </main>
  <?php include('../includes/layout/footer.php') ?>
</body>
</html>