<?php 
include('../php/protect.php');
include('../php/protectadm.php');
include('../includes/layout/header.php');
?>
  <main>
    <div class="titulopagina">
      <h2>Administração</h2>
    </div>
   
<div class="container">
		    <div class="MenuPrincipal" > 
          <a href="tecnicos.php">
            <button class="meu-botão">Tecnicos</button> <br/>
            </a>
            <a href="HistoricoPreventivas.php">
              <button class="meu-botão">Historico Geral de Preventivas</button> <br/>
            </a>
            <a href="adicionartv.php">
              <button class="meu-botão">Adicionar TV</button> <br/>
            </a>
            <a href="AdicionarCamera.php">
              <button class="meu-botão">Adicionar Camera</button> <br/>
            </a>
            <a href="dashboard-preventivas.php">
              <button class="meu-botão">Dashboard Preventivas</button> <br/>
            </a>
        </div>
		</div>
  </main>

<?php include('../includes/layout/footer.php') ?>
</body>

</html>