<?php 
include('../php/realizarLogin.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="../img/iconNaxsys.png" type="image/png">
<title>Quadrados</title>
<style>
    body {
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #f0f0f0;
    }
    
    .quadrado {
        width: 450px;
        height: 300px;
        background-color: #73CCC3;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #000;
        font-size: 24px;
	border-radius: 8px;
    }


 body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #F0F0F0;
    }

    .container {
        width: 400px;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
        margin-bottom: 20px;
        color: #696969
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }


    .form-group input[type="email"],
    .form-group input[type="password"]{
        width: 100%;
        padding: 10px;
        border: 1px solid #73CCC3;
        border-radius: 15px;
        box-sizing: border-box;
    }

    .form-group input:hover {
        border-color: #CCC;
    }


    .form-group textarea {
        resize: vertical;
        min-height: 100px;
    }

    .form-group button {
        padding: 10px 20px;
        background-color: #73CCC3;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;

    }

    .form-group button:hover {
        background-color: #CCC;
    }
	#botao {
	margin-left: 10px;
}
	.button-container {
        display: flex;
	justify-content: right;
	
}

	#logo {
	width: 50%;
	
}
	.logocontainer {
	display: flex;
	justify-content: center;
}
    h2 {
        color: #696969;
    }
    

</style>
</head>
<body>


    <div class="quadrado">
<div class="container">
	<div class="logocontainer">
	<img id="logo" src="../img/Logo Naxsys Brasil.jpg" alt="Naxsys Brasil">
	</div> 
        <h2>Login</h2>
        <form action="#" method="post">
            <div class="form-group">
                <label for="nome">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
              
            </div>
            
            <div class="form-group">
		<div class="button-container">
               
		<button id="botao" type="submit">Entrar</button>
       
            	</div>
                
	    </div>
        </form>
    </div>

    </div>

</body>

</html>
