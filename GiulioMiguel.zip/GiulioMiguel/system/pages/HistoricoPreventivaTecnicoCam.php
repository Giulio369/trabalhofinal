<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>
<style>
.form-group {
    margin-bottom: 20px;
    color: #696969;
    display: flex; 
    align-items: center;
    }

    .form-group input:hover {
        border-color: #CCC;
    }


    .form-group textarea {
        resize: vertical;
        min-height: 100px;
    }
    .form-group input {
        width: 340px;
    }



    .container-form {
        display: flex;
        text-align: center;
        width: auto;
    }
    .buttonClass {
    width: 40px;
    height: 40px;
    margin-left: 5px;
    border-radius: 50%;
    padding: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    
    }
    .buttonClass img {
    width: 40px; 
    height: 40px;
    
    }


</style>
        <main>
       <div class="titulopagina">
        <h2>Historico de Preventiva de Camera</h2>
        </div>
        <div class="centralizar">
    <div class="containerTecnicos">
        <button class="botaoPequeno" onclick="exportToExcelPrevCam()">Exportar</button>
        <script src="../scripts/exportPreventivaCamera.js"></script>
    </div>
    </div>

    <div class="container-form">
            <form class="form-group" action='' method='GET'>
                <input type='text' name='search' placeholder='Pesquisar TV'>
                <button class="buttonClass" type='submit' value='Buscar'><img src='../img/lupabranca.png' alt='Ícone de busca'></button>

            </form>
        </div>
        
        <table class="centralizar">
            <tr>
            </tr>
            <?php include '../php/MostrarHistoricoPreventivaTecnicoCam.php'; ?>
        </table>


    <div class="centralizar">
      <a href="index.php">
      <button id="voltar">Voltar</button> <br/>
      </a>
    </div>
    <?php include('../includes/layout/footer.php') ?>
</body>
</html>