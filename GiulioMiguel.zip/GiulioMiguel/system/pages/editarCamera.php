<?php
include('../php/conexao.php'); 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/get_camera_nome.php');
?>
<main>
<div class="titulopagina">
    <h2>Administração</h2>
</div>

<div class="containerForm">
    <div class="form-group">
        <div class="containerAdd">
            <h2>Editar Câmera</h2>
            <form id="EditCamera" action="../php/processar_edicaoCamera.php" method="POST">
                <input type="hidden" name="camera_nome" value="<?php echo $nome; ?>">
                <label for="local">Local:</label>
                <input type="text" id="local" name="local" value="<?php echo $camera['local']; ?>"><br>
                
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" value="<?php echo $camera['nome']; ?>"><br>
                
                <label for="ip">IP:</label>
                <input type="text" id="ip" name="ip" value="<?php echo $camera['ip']; ?>"><br>
                
                <label for="marca">Marca:</label>
                <input type="text" id="marca" name="marca" value="<?php echo $camera['marca']; ?>"><br>
                
                <label for="modelo">Modelo:</label>
                <input type="text" id="modelo" name="modelo" value="<?php echo $camera['modelo']; ?>"><br>
                
                
                <label for="dataInstalacao">Data de Instalação:</label>
                <input type="date" id="dataInstalacao" name="dataInstalacao" value="<?php echo $camera['dataInstalacao']; ?>"><br>
                
                <div class="containerLine">
                    <button class="botaoMenor" id="botaoSubmit" type="submit" value="Salvar Alterações">Salvar</button> 
                </div>
            </form>
        </div>
    </div>
</div>

</main>

<br><br><br>
<?php include('../includes/layout/footer.php') ?>
