<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
?>
  <main>
    <div class="titulopagina">
      <h2>Administração</h2>
    </div>
   
  <div class="containerForm">
    <form id="AddTec" action="../php/adicionarTecnico.php" method="post">
      <div class="form-group">
        <div class="containerAdd">
        <h2 style="text-align: center;">Adicionar Tecnico</h2>
        <label>Nome:</label>
          <input type="text" name="nome" required>
          <label>Email:</label> 
          <input type="email" name="email" required>
          <label>Cargo:</label> 
          <input type="text" name="cargo" required>
          <label>Nivel:</label> 
          <input type="text" name="nivel" required>
          <label>Senha de acesso:</label> 
          <input type="password" id="senha" name="senha" required>
          <label>Confirme a senha:</label>
          <input type="password" id="confirmPassword" name="confirmPassword" required>
          <div id="mensagemErro" style="color: red; display: none;">As senhas não coincidem.</div>
      <div class="containerLine">
        <button class="botaoMenor" id="botaoSubmit" type="submit">Cadastrar</button> 
        </form>
        <a href="tecnicos.php">
        <button type="button" class="botaoMenor">Cancelar</button> 
        </a>
      </div>
     
        </div>
        </div>

  </div>

  </main>


<script>
  document.getElementById("AddTec").addEventListener("submit", function(event) {
    event.preventDefault(); 
    var senha = document.getElementById("senha").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // Verifica se as senhas coincidem
    if (senha !== confirmPassword) {
      document.getElementById("mensagemErro").style.display = "block";
    } else {
      document.getElementById("mensagemErro").style.display = "none";

      this.submit(); 
    }
  });
</script>
<br><br><br>
<?php include('../includes/layout/footer.php') ?>
</body>
</html>
