<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>

    <main>
      <br/><br/><br/><br/><br/><br/><br/><br/><br/>
      <h2 class="SGPN">SGPN </h2>
      <h2 class="SGPN2">Sistema de Gerenciamento de Preventivas</h2>
      <h2 class="SGPN3">SGPN</h2>

    <div class="container">
		    <div class="MenuPrincipal" > 
          <a href="iniciarpreventiva.php">
            <button class="meu-botão">Iniciar Preventiva</button> <br/>
            </a>
            <a href="cameras.php">
              <button class="meu-botão">Câmeras</button> <br/>
            </a>
            <a href="tvs.php">
              <button class="meu-botão">Televisões</button> <br/>
            </a>

            <a href="historicopreventivastecnico.php">
              <button class="meu-botão">Histórico de Preventivas</button> <br/>
            </a>

            
            <a href="PreventivasPendentes.php">
              <button class="meu-botão">Preventivas Pendentes</button> <br/>
            </a>

            <a href="ConfirmarLogout.php">
              <button class="meu-botão">Sair</button> <br/>
            </a>
        </div>
		</div>

    </main>

<?php include('../includes/layout/footer.php') ?>
