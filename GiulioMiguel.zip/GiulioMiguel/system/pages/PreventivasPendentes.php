<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>


        <main>
      <div class="titulopagina">
        <h2 style ="text-align: center; ">Preventivas Pendentes</h2>
      </div>
       
      </div>

  <div class="centro">
    <div class="centralizar">
   
      <a href="CamerasPendentes.php">
        <button>Cameras Pendentes</button>
      </a>
    </div>

     
    <div class="centralizar">
      <a href="TelevisoesPendentes.php">
        <button>Televisoes Pendentes</button>
      </a>
    </div>

     <div class="centralizar"> 
      <a href="index.php">
        <button>Voltar</button> 
      </a>
     </div>
    </div>

    <?php include('../includes/layout/footer.php') ?>
</body>
</html>