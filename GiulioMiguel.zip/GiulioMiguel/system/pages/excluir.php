<?php
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/conexao.php'); 
include('../php/get_tecnico_id.php');
?>

<main>
    <style>
    .ContainerExclusao {
        width: auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    }
    .botoes {
        display: flex;
        justify-content: right;
    }

    h3 {
        color: red;
    }
    h2 {
        color: #73CCC3;
    }

    </style>
    <div class="titulopagina">
       
    </div>

    <div class="containerForm">
        <div class="form-group">
            <div class="ContainerExclusao">
            <h2>Excluir Técnico</h2>
            <h3>Você tem certeza que deseja excluir o técnico abaixo?</h3>
            <p><strong>Nome:</strong> <?php echo $tecnico['nome']; ?></p>
            <p><strong>Cargo:</strong> <?php echo $tecnico['cargo']; ?></p>
            <p><strong>Email:</strong> <?php echo $tecnico['email']; ?></p>
            <p><strong>Nível:</strong> <?php echo $tecnico['nivel']; ?></p>
            <form action="../php/processar_exclusao.php" method="post">
                <input type="hidden" name="id_tecnico" value="<?php echo $id_tecnico; ?>">
                <div class="botoes">
                    <button class="botaoPequeno" type="submit">Confirmar</button>
                    <a href="detalhes.php?id=<?php echo $id_tecnico ?>">
                    <button class="botaoPequeno" type="button">Cancelar</button>
                    </a>
                </div>
            </form>
           
            </div>
        </div>
    </div>
</main>

<?php include('../includes/layout/footer.php') ?>
</body>
</html>
