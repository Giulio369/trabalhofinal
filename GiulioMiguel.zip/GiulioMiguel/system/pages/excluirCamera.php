<?php
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/conexao.php'); 

include('../php/get_camera_nome.php');
?>

<main>
    <style>
    .ContainerExclusao {
        width: auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    }
    .botoes {
        display: flex;
        justify-content: right;
    }

    h3 {
        color: red;
    }
    h2 {
        color: #73CCC3;
    }

    </style>
    <div class="titulopagina">

    </div>

    <div class="containerForm">
        <div class="form-group">
            <div class="ContainerExclusao">
            <h2>Excluir Câmera</h2>
            <h3>Você tem certeza que deseja excluir a câmera abaixo?</h3>
            <p><strong>Local:</strong> <?php echo $camera['local']; ?></p>
            <p><strong>Nome:</strong> <?php echo $camera['nome']; ?></p>
            <p><strong>IP:</strong> <?php echo $camera['ip']; ?></p>
            <p><strong>Marca:</strong> <?php echo $camera['marca']; ?></p>
            <p><strong>Modelo:</strong> <?php echo $camera['modelo']; ?></p>
            <p><strong>Data de instalacao:</strong> <?php echo $camera['dataInstalacao']; ?></p>
            <form action="../php/processar_exclusaoCamera.php" method="post">
                <input type="hidden" name="nome" value="<?php echo $nome; ?>">
                <div class="botoes">
                    <button class="botaoPequeno" type="submit">Confirmar</button>
                    <a href="detalhesCamera.php?camera_nome=<?php echo $nome ?>">
                    <button class="botaoPequeno" type="button">Cancelar</button>
                    </a>
                </div>
            </form>
           
            </div>
        </div>
    </div>
</main>

<?php include('../includes/layout/footer.php') ?>
</body>
</html>
