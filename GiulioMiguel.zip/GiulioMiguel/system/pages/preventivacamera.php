<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/preventivacamera.php')
?>

  <main>
    <div class="titulopagina">
      <h2>Preventiva de Câmera</h2>
    </div>


<div class="centralizar"> 
    <form action="#" method="post">
      <div class="form-group">
        <label>Patch Cord:</label> <input type="select" name="patchCord" required><br>
        <label>Cabo:</label> <input type="text" name="cabo" required><br>
        <label>Vidro:</label> <input type="text" name="Vidro" required><br>
        <label>Acrilico:</label> <input type="text" name="Acrilico" required><br>
        <label>Lente:</label> <input type="text" name="lente" required><br>
        <label>Foco:</label> <input type="text" name="Foco" required><br>
        <label>Qualidade de Vídeo:</label> <input type="text" name="Qualidade" required><br>
        <label>Observação:</label> <input type="text" name="observacao"><br>
        <button type="submit">Finalizar</button> 
      </div>
  </form>
</div>


    
    <div class="centralizar"> 
      <a href="iniciarpreventiva.php">
        <button>Voltar</button> 
      </a>
    </div>

  </main>
  
<?php include('../includes/layout/footer.php') ?>
</body>
</html>