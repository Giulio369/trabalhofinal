<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>

        <main>
       <div class="titulopagina">
        <h2>Ordens a Executar</h2>
        </div>
        

        <div class="centralizar">
    <div class="containerTecnicos">
        <button class="botaoPequeno" onclick="exportToExcelPrevCam()">Exportar</button>
        <script src="../scripts/exportPreventivaCamera.js"></script>
    </div>
    </div>
    <div class="ContainerPlanon">
            <div class="form-group">
                <label>Order Planon</label>
                <input style="width: 400px;"type="text" name="orderplanon" required>
                </div>
                <button style="width: 130px;"class="botaoPequeno" type="submit">Ver detalhes</button>
        </div>
 
        <table class="centralizar">
            <tr>
            </tr>
            <?php include '../php/MostrarOrdens.php'; ?>
        </table>
        


    <div class="container">
      <a href="index.php">
      <button id="voltar">Voltar</button> <br/>
      </a>
    </div>
    <?php include('../includes/layout/footer.php') ?>
</body>
</html>