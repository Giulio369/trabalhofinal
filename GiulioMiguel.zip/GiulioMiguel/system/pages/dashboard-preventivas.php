<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Gráfico de Pizza</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="icon" href="../img/iconNaxsys.png" type="image/png">
  <style>
   
    #pieChartContainer {
      display: flex;
      justify-content: center;
      align-items: top;
      height: 100vh; 
    }

    canvas {
      width: 500px; 
      height: 500px; 
    }
    .ControlePreventivas {
        text-align: center;
        color: #999898 ;
    }
    .descricao {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 650px;
    }
    .container {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .containerText {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 150px;
    }
    .containerGraficoLinha {
      display: flex;
      justify-content: center;
      align-items: center;
      padding-top: -100px;
    }
    #SemanalCameras {
      width: 250px;
      
    } 
    body {
      background-color: #1F2840;

    }
    .data-hora {
        color: white;
    }
    .cicloAtual {
        text-align: center;
        color: #999898 ;
    }
  </style>
</head>

<body>
    <h2 class="ControlePreventivas">CONTROLE DE PREVENTIVAS</h2>
    
    <h2 class="ControlePreventivas" id="cicloAtual"></h2>
  <script src="../scripts/obterCicloData.js"></script>
  <div class="container">
  <canvas id="PreventivasSemanais"></canvas>
  </div>
    <h2 class="ControlePreventivas"> </h2>
    <div class="container">
        <div class="descricao">
          <div class="containerText">
            
           <h2 class="ControlePreventivas">CAMERA</h2>
        </div>
          <div class="containerText">
           <h2 class="ControlePreventivas">TELEVISÃO</h2>
          </div>
      </div>
    </div>

  <div id="pieChartContainer">
    <canvas id="Cameras"></canvas> <!--Grafico Cameras -->
    <canvas id="Televisoes"></canvas> <!-- Grafico Televisoes -->

  </div>

    <div class="containerGraficoLinha">
       
  <canvas id="SemanalCameras"></canvas> <!-- Grafico Semanal Cameras -->
  <canvas id="SemanalTelevisoes"></canvas> <!-- Grafico Semanal Televisoes -->

  </div>
  <!--Scripts-->
  <script src="../scripts/graficoPrevCamera.js"></script> <!-- Grafico Pizza Cameras-->
  <script src="../scripts/graficoPrevTelevisao.js"></script> <!-- Grafico Pizza Televisoes-->
  <script src="../scripts/graficoSemanalCamera.js"></script> <!--Grafico Semanal Cameras-->
  <script src="../scripts/graficoSemanalTelevisao.js"></script> <!--Grafico Semanal Televisoes-->

    <script src="../scripts/script.js"></script>
  <!--/Scripts-->


</body>
</html>
