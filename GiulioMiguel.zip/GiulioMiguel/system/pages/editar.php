<?php
include('../php/conexao.php'); 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/get_tecnico_id.php');
?>
<main>
<div class="titulopagina">
      <h2>Administração</h2>
    </div>

    
<div class="containerForm">
    <div class="form-group">
        <div class="containerAdd">
        <h2>Editar Técnico</h2>
    <form id="AddTec" action="../php/processar_edicao.php" method="POST">
        <input type="hidden" name="id_tecnico" value="<?php echo $id_tecnico; ?>">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $tecnico['nome']; ?>"><br>
        
        <label for="cargo">Cargo:</label>
        <input type="text" id="cargo" name="cargo" value="<?php echo $tecnico['cargo']; ?>"><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $tecnico['email']; ?>"><br>
        
        <label for="nivel">Nível:</label>
        <input type="text" id="nivel" name="nivel" value="<?php echo $tecnico['nivel']; ?>"><br>
        
        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required>
        <label>Confirme a senha:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" required>
        <div id="mensagemErro" style="color: red; display: none;">As senhas não coincidem.</div>
        <div class="containerLine">
        <button class="botaoMenor" id="botaoSubmit" type="submit" value="Salvar Alterações">Salvar</button> 
    </form>
        </div>
        </div>
    </div>
</div>

</main>


<script>
  document.getElementById("AddTec").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita o envio do formulário

    var senha = document.getElementById("senha").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // Verifica se as senhas coincidem
    if (senha !== confirmPassword) {
      document.getElementById("mensagemErro").style.display = "block";
    } else {
      document.getElementById("mensagemErro").style.display = "none";
      // Se as senhas coincidirem, você pode prosseguir com o envio do formulário
      this.submit(); // Envio do formulário
    }
  });
</script>
<br><br><br>
<?php include('../includes/layout/footer.php') ?>