<?php
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/conexao.php'); 

if(isset($_GET['televisao_serial'])) {
    $serial = mysqli_real_escape_string($mysqli, $_GET['televisao_serial']); // Prevenir SQL Injection
    $consulta = "SELECT local, marca, polegadas, dataInstalacao FROM televisao WHERE serial = '$serial'"; 
    $resultadoDetalhes = mysqli_query($mysqli, $consulta);
    
    if(mysqli_num_rows($resultadoDetalhes) > 0) {
        $televisao = mysqli_fetch_assoc($resultadoDetalhes);
?>

<main>
    <style>
        .ContainerExclusao {
            width: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        .botoes {
            display: flex;
            justify-content: right;
        }
        h3 {
            color: red;
        }
        h2 {
            color: #73CCC3;
        }
    </style>
    <div class="titulopagina"></div>
    <div class="containerForm">
        <div class="form-group">
            <div class="ContainerExclusao">
                <h2>Excluir Televisão</h2>
                <h3>Você tem certeza que deseja excluir a televisão abaixo?</h3>
                <p><strong>Local:</strong> <?php echo $televisao['local']; ?></p>
                <p><strong>Marca:</strong> <?php echo $televisao['marca']; ?></p>
                <p><strong>Polegadas:</strong> <?php echo $televisao['polegadas']; ?></p>
                <p><strong>Data de Instalação:</strong> <?php echo $televisao['dataInstalacao']; ?></p>
                <form action="../php/processar_exclusaoTelevisao.php" method="post">
                    <input type="hidden" name="televisao_serial" value="<?php echo $serial; ?>">
                    <div class="botoes">
                        <button class="botaoPequeno" type="submit">Confirmar</button>
                        <a href="detalhesTv.php?televisao_serial=<?php echo $serial; ?>">
                            <button class="botaoPequeno" type="button">Cancelar</button>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<?php
    } else {
        header("Location: DetalhesTv.php");
        echo "Câmera não encontrada, excluída ou inexistente!";
    }
} else {
    echo "Serial da televisão não especificado.";
}
include('../includes/layout/footer.php');
?>
