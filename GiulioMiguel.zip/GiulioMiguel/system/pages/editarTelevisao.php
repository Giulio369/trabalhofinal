<?php
include('../php/conexao.php');
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/get_televisao_serial.php');
?>

<main>
    <div class="titulopagina">
        <h2>Administração</h2>
    </div>

    <div class="containerForm">
        <div class="form-group">
            <div class="containerAdd">
                <h2>Editar Televisão</h2>
                    <form id="EditTelevisao" action="../php/processar_edicaoTelevisao.php" method="POST">
                        <input type="hidden" name="televisao_serial" value="<?php echo $serial; ?>">
                        
                        <label for="local">Local:</label>
                        <input type="text" id="local" name="local" value="<?php echo $televisao['local']; ?>"><br>
                        
                        <label for="marca">Marca:</label>
                        <input type="text" id="marca" name="marca" value="<?php echo $televisao['marca']; ?>"><br>
                        
                        <label for="polegadas">Polegadas:</label>
                        <input type="text" id="polegadas" name="polegadas" value="<?php echo $televisao['polegadas']; ?>"><br>
                        
                        <label for="dataInstalacao">Data de Instalação:</label>
                        <input type="date" id="dataInstalacao" name="dataInstalacao" value="<?php echo $televisao['dataInstalacao']; ?>"><br>
                        
                        <label for="serial">Serial:</label>
                        <input type="text" id="serial" name="serial" value="<?php echo $televisao['serial']; ?>"><br>
                        
                        <div class="containerLine">
                            <button class="botaoMenor" id="botaoSubmit" type="submit" value="Salvar Alterações">Salvar</button>
                        </div>
                    </form>
            </div>
        </div>
    </div>
</main>

<br><br><br>
<?php include('../includes/layout/footer.php') ?>
