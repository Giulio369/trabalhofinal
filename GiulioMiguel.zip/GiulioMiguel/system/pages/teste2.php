<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleção de Câmeras</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Seleção de Câmeras</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <select name="localSelect" id="localSelect">
    <?php
   
     $servername = "localhost";
     $username = "root";
     $password = "@admin";
     $dbname = "sgpn";
     $conn = new mysqli($servername, $username, $password, $dbname);

    
     if ($conn->connect_error) {
         die("Erro na conexão com o banco de dados: " . $conn->connect_error);
     }
            $sql = "SELECT local FROM camera";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row["local"] . "'>" . $row["local"] . "</option>";
                }
            } else {
                echo "<option value=''>Nenhum local encontrado</option>";
            }

            $conn->close();
            ?>
    </select>
    <input type="submit" value="Selecionar">
</form>

<select name="cameraSelect" id="cameraSelect">
    <?php include '../php/get_cameras.php'; ?>
</select>

</body>
</html>
