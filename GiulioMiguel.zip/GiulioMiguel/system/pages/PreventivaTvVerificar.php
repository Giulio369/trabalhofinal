<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/preventivaTvVerificar.php');
include('../php/ControlarCiclo.php');
?>

  <main>
    <div class="titulopagina">
      <h2>Preventiva de Televisão</h2>
      <h3>Ciclo <?php echo $ciclo;  ?> do ano <?php echo $ano; ?> </h3>
    </div>


<div class="centralizar"> 
    <form action="#" method="post">
      <div class="form-group">
        <label>Televisão</label>
        <input type="text" name="serial" required placeholder="Digite o serial da TV"><br>
        <button type="submit">Próximo</button> 
    </div>
  </form>
</div>


    
    <div class="centralizar"> 
      <a href="iniciarpreventiva.php">
        <button>Voltar</button> 
      </a>
    </div>

  </main>
  
<?php include('../includes/layout/footer.php') 
?>
</body>
</html>