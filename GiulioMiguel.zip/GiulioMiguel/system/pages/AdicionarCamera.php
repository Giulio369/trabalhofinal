<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
include('../php/protectadm.php');
include('../php/adicionarcamera.php');
?>
  <main>
    <div class="titulopagina">
      <h2>Administração</h2>
    </div>
   
  <div class="containerForm">
    <form id="AddTec" action="#" method="post">
      <div class="form-group">
        <div class="containerAdd">
        <h2 style="text-align: center;">Adicionar Camera</h2>
        <label>Local:</label>
          <input type="text" name="local" required>
          <label>Nome:</label> 
          <input type="text" name="nome" required>
          <label>IP:</label> 
          <input type="text" name="ip" required>
          <label>Marca:</label> 
          <input type="text" name="marca" required>
          <label>Modelo:</label> 
          <input type="text" name="modelo" required>
          <label>Data Instalacao</label>
          <input type="date"  name="dataInstalacao" required>
          <div id="mensagemErro" style="color: red; display: none;">As senhas não coincidem.</div>
      <div class="containerLine">
        <button class="botaoMenor" id="botaoSubmit" type="submit">Cadastrar</button> 
        </form>
        <a href="adm.php">
        <button type="button" class="botaoMenor">Cancelar</button> 
        </a>
      </div>
     
        </div>
        </div>

  </div>

  </main>


<br><br><br>
<?php include('../includes/layout/footer.php') ?>
</body>
</html>
