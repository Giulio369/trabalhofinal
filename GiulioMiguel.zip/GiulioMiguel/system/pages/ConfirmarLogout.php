<?php 
include('../php/protect.php');
include('../includes/layout/header.php');
?>


        <main>
           

    <div class="titulopagina">
        <h2>Você realmente deseja sair?</h2>
    </div>

  <div class="container">
    <div class="menuprincipal">
    <a href="../php/RealizarLogout.php">
      <button id="voltar">Confirmar</button> <br/>
      </a>
      <a href="index.php">
      <button id="voltar">Voltar</button> <br/>
      </a>
    </div>
    </div>
    <?php include('../includes/layout/footer.php') ?>
</body>
</html>