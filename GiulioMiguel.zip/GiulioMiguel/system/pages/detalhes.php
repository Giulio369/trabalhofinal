<?php 
include('../php/protect.php');
include('../php/protectadm.php');
include('../includes/layout/header.php');

?>
<style>
    .containerDetalhes {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 50vh;
    }

    .DetalhesTecnico {    
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); 
        padding: 20px; 
        width: auto;
        border-radius: 10px;
    }
    .DetalhesTecnico p {
        color: #696969;
        border-color: #000;
    }
    .DetalhesTecnico h2 {
        color: #73CCC3;
        border-color: #000;
    }
    h3 {
        color: #73CCC3;
    }
    .containerBotoes {
    display: flex;
    justify-content: space-between;
}
</style>
<main>
    <div class="titulopagina">
    
    </div>

    </div>
    <div class="containerDetalhes">
        <div class="DetalhesTecnico"> 
            <div class="CaixaDetalhes">
                <?php include('../php/MostrarDetalhesTecnico.php'); ?>
            </div>
        </div>
    </div>

</main>

<?php include('../includes/layout/footer.php') ?>
</body>

</html>
