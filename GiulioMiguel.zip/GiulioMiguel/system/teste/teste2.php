<?php 
include('teste.php');
echo $variavel;
?>