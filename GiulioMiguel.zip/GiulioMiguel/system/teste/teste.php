<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caixa de Seleção Múltipla</title>
</head>
<body>
    <h2>Escolha suas frutas favoritas:</h2>
    <form action="/submit" method="post">
        <label for="frutas">Frutas:</label>
        <select id="frutas" name="frutas" multiple>
            <option value="maca">Maçã</option>
            <option value="banana">Banana</option>
            <option value="laranja">Laranja</option>
            <option value="uva">Uva</option>
            <option value="morango">Morango</option>
        </select><br><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>