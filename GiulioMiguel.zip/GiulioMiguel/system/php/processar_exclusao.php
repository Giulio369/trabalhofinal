<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    include('../php/conexao.php');
    $id_tecnico = $_POST['id_tecnico'];
    $consulta = "DELETE FROM tecnico WHERE id = $id_tecnico";

    if (mysqli_query($mysqli, $consulta)) {
        header("Location: ../pages/tecnicos.php");
        exit();
    } else {
        echo "Erro ao excluir o técnico: " . mysqli_error($mysqli);
    }
    mysqli_close($mysqli);
} else {
    header("Location: index.php");
    exit();
}
?>
