<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$mysqli = new mysqli($host, $usuario, $senha, $banco);

if($mysqli->error) {
    die("Falha ao conectar ao banco de dados: " . $mysqli->error);
}