<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   include('../php/conexao.php');

    $camera_nome_antigo = $_POST['camera_nome']; 
    $camera_nome_novo = $_POST['nome']; 
    $local = $_POST['local'];
    $ip = $_POST['ip'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $dataInstalacao = $_POST['dataInstalacao'];

    $consulta = "UPDATE camera SET nome='$camera_nome_novo', local='$local', ip='$ip', marca='$marca', modelo='$modelo', dataInstalacao='$dataInstalacao' WHERE nome='$camera_nome_antigo'";

    if (mysqli_query($mysqli, $consulta)) {
        header("Location: ../pages/detalhesCamera.php?camera_nome=$camera_nome_novo");
        exit();
    } else {
        echo "Erro ao atualizar os dados da câmera: " . mysqli_error($mysqli);
    }

    mysqli_close($mysqli);
} else {
    header("Location: index.php");
    exit();
}
?>
