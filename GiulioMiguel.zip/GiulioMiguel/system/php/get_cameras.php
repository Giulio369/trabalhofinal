
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "@admin";
    $dbname = "sgpn";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    if(isset($_POST['localSelect']) && !empty($_POST['localSelect'])) {
        $local = $_POST['localSelect'];

        $sql = "SELECT nome FROM camera WHERE local = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $local);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<option value='" . $row["nome"] . "'>" . $row["nome"] . "</option>";
            }
        } else {
            echo "<option value=''>Nenhuma câmera encontrada para este local</option>";
        }
    } else {
        echo "<option value=''>Selecione um local válido</option>";
    }

    $conn->close();
}
?>
