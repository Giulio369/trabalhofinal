<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

if(isset($_GET['televisao_serial'])) {
    $serial = mysqli_real_escape_string($conexao, $_GET['televisao_serial']); 
    
    if (is_numeric($serial)) {
        $consulta = "SELECT serial, marca, polegadas, local, dataInstalacao FROM televisao WHERE serial = $serial";
    } else {
        $consulta = "SELECT serial, marca, polegadas, local, dataInstalacao FROM televisao WHERE serial = '$serial'";
    }
    $consultaPreventivasTelevisao = "SELECT COUNT(*) AS Preventivas_Televisao FROM preventivatelevisaotecnico WHERE serialTv = '$serial'";
    
    $resultadoDetalhes = mysqli_query($conexao, $consulta);
    
    $resultadoPreventivasTelevisao = mysqli_query($conexao, $consultaPreventivasTelevisao);
    
    if(mysqli_num_rows($resultadoDetalhes) > 0) {
        $televisao = mysqli_fetch_assoc($resultadoDetalhes);
        
        $dadosPreventivasTelevisao = mysqli_fetch_assoc($resultadoPreventivasTelevisao);
        $preventivas_televisao_realizadas = $dadosPreventivasTelevisao['Preventivas_Televisao'];
        
        echo "<h2><strong>Informações da Televisão</strong></h2>";
        echo "<p><strong>Serial:</strong> " . $televisao['serial'] . "</p>";
        echo "<p><strong>Marca:</strong> " . $televisao['marca'] . "</p>";
        echo "<p><strong>Polegadas:</strong> " . $televisao['polegadas'] . "</p>";
        echo "<p><strong>Local:</strong> " . $televisao['local'] . "</p>";
        echo "<p><strong>Data Instalacao:</strong> " . $televisao['dataInstalacao'] . "</p>";
        echo "<p><strong>Preventivas Recebidas:</strong> " . $preventivas_televisao_realizadas . "</p>";
       
        echo "<div id='EditarExcluir' class='containerBotoes'>";
        echo "<a href='editartelevisao.php?televisao_serial=" . $serial . "'>";
        echo "<button class='botaoPequeno'>Editar</button>";
        echo "</a>";
        echo "<a href='excluirtelevisao.php?televisao_serial=" . $serial . "'>";
        echo "<button class='botaoPequeno'>Excluir</button>";
        echo "</a>";

        echo "</div>";
    } else {
        
        echo "Nenhuma Televisao encontrada com o nome fornecido.";
    }
} else {
    echo "Nome da Televisao não especificado.";
}

mysqli_close($conexao);
?>
