<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['nome'])){
    header("Location: ../pages/ErroLoginOff.php");
    exit; 
}

$conn = new mysqli("localhost", "root", "@admin", "sgpn");

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$nome = $_SESSION['nome'];
$query = "SELECT nivel FROM tecnico WHERE nome = '$nome'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nivel_usuario = $row['nivel'];
    
    $nivel_necessario = 1; 
    
    if ($nivel_usuario < $nivel_necessario) {
        header("Location: ../pages/ErroPermissao.php");
        exit; 
    }
} else {

    header("Location: ../pages/ErroLoginOff.php");
    exit; 
}

?>
