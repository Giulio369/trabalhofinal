<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../php/conexao.php');

    $serial = $_POST['televisao_serial'];

    $consulta = "DELETE FROM televisao WHERE serial = '$serial'";

    if (mysqli_query($mysqli, $consulta)) {
        header("Location: ../pages/tvs.php");
        exit();
    } else {
        echo "Erro ao excluir a televisão: " . mysqli_error($mysqli);
    }

    mysqli_close($conexao);
} else {
    header("Location: index.php");
    exit();
}
?>
