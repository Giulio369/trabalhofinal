<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);
if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}

if(isset($_POST['patchCord'])) {
    $nome = $_SESSION['nomeCamera'];
    $patchCord = $_POST['patchCord'];
    $cabo = $_POST['cabo'];
    $Vidro = $_POST['Vidro'];
    $Acrilico = $_POST['Acrilico'];
    $Lente = $_POST['lente'];
    $Foco = $_POST['Foco'];
    $Qualidade = $_POST['Qualidade'];
    $observacao = $_POST['observacao'];

    if(strlen($nome) == 0) {
        echo '<script>alert("Câmera não especificada!!");</script>';
    } else {
        $nome = $conexao->real_escape_string($nome);

        $sql_code = "SELECT * FROM camera WHERE nome = '$nome'";
        $sql_query = $conexao->query($sql_code) or die("Falha na execução do código SQL: " . $conexao->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
    
            $idTecnico = $_SESSION['id'];
            $NomeTecnico = $_SESSION['nome'];

            $horaInicio = $_SESSION['horaInicio'];
            $horaTermino = date('H:i:s'); 

            $sql_camera = "INSERT INTO PreventivaCamera (patchCord, cabo, Vidro, Acrilico, lente, foco, qualidade, observacao) 
                           VALUES ('$patchCord', '$cabo', '$Vidro', '$Acrilico', '$Lente', '$Foco', '$Qualidade', '$observacao')";
            mysqli_query($conexao, $sql_camera) or die("Erro ao inserir na tabela camera: " . mysqli_error($conexao));


            $idPreventiva = mysqli_insert_id($conexao);


            $sql_preventiva = "INSERT INTO PreventivaCameraTecnico (fk_PreventivaCamera_id, fk_Tecnico_id, nomeCamera, nomeTecnico, horaInicio, horaTermino, dataHora) 
                               VALUES ('$idPreventiva', '$idTecnico', '$nome', '$NomeTecnico','$horaInicio','$horaTermino', now())";
            mysqli_query($conexao, $sql_preventiva) or die("Erro ao inserir na tabela PreventivaCameraTecnico: " . mysqli_error($conexao));
            $_SESSION['CameraRealizada'] = $_SESSION['nomeCamera'];
            unset($_SESSION['nomeCamera']);
            header("Location: ../pages/preventivaCamRealizada.php");
            exit(); 
        } else {
            echo '<script>alert("Câmera Inexistente! Tente novamente!");</script>';
            header("Location: ../pages/preventivaCamNaoRealizada.php");
        }
    }
}

mysqli_close($conexao);
?>
