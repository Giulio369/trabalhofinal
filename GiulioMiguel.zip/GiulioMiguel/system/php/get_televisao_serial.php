<?php 
if(isset($_GET['televisao_serial'])) {
    $serial = mysqli_real_escape_string($mysqli, $_GET['televisao_serial']);
    
    $consulta = "SELECT serial, marca, polegadas, local, dataInstalacao FROM televisao WHERE serial = '$serial'";
    
    $resultado = mysqli_query($mysqli, $consulta);
    
    if(mysqli_num_rows($resultado) > 0) {
        $televisao = mysqli_fetch_assoc($resultado);
    } else {
        echo "Nenhuma Televisao encontrada com o nome fornecido.";
        exit(); 
    }
} else {
    echo "Nome da Televisao não especificado.";
    exit(); 
}

mysqli_close($mysqli);
?>
