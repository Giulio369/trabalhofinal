<?php 
if(isset($_GET['camera_nome'])) {
    $nome = mysqli_real_escape_string($mysqli, $_GET['camera_nome']);
    
    $consulta = "SELECT  local, nome, ip, marca, modelo, dataInstalacao  FROM camera WHERE nome = '$nome'";
    
    $resultado = mysqli_query($mysqli, $consulta);
    
    if(mysqli_num_rows($resultado) > 0) {
        $camera = mysqli_fetch_assoc($resultado);
    } else {
        header('location: detalhesCamera.php');
        echo "Nenhuma câmera encontrada com o nome fornecido.";
        exit(); 
    }
} else {
    echo "Nome da câmera não especificado.";
    exit(); 
}

mysqli_close($mysqli);
?>
