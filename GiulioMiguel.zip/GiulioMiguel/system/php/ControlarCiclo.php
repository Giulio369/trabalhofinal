<?php 
date_default_timezone_set('America/Sao_Paulo');

$ano = date('Y');
$mes = date('m');

if ($mes < 4) {
    $ciclo = 1;
    $mesInicio = 1;
    $mesFinal = 3;
} 
elseif ($mes > 3 && $mes < 7) {
    $ciclo = 2;
    $mesInicio = 4;
    $mesFinal = 6;
} 
elseif ($mes > 6 && $mes < 10)  {
    $ciclo = 3;
    $mesInicio = 7;
    $mesFinal = 9;
} 
else {
    $ciclo = 4;
    $mesInicio = 10;
    $mesFinal = 12;
} 

?>
