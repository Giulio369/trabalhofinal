<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../php/conexao.php');
    $nome = $_POST['nome'];
    $consulta = "DELETE FROM camera WHERE nome = '$nome'";


    if (mysqli_query($mysqli, $consulta)) {

        header("Location: ../pages/cameras.php");
        exit();
    } else {
        echo "Erro ao excluir a camera: " . mysqli_error($mysqli);
    }


    mysqli_close($mysqli);
} else {
    header("Location: index.php");
    exit();
}
?>
