<?php
$servername = "localhost"; 
$username = "root"; 
$password = "@admin";
$database = "sgpn"; 

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
$sql = "SELECT YEARWEEK(dataHora) AS week, COUNT(*) AS count FROM preventivacameratecnico GROUP BY week";

$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($data);
?>

