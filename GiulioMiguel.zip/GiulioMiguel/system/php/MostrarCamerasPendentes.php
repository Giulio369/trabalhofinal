<?php

$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}
include('ControlarCiclo.php');
$resultados_por_pagina = 20;

$pagina_atual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

$offset = ($pagina_atual - 1) * $resultados_por_pagina;

if(isset($_GET['search'])){

    $termo_pesquisa = $_GET['search'];
    $consulta = "SELECT nome, ip, local, marca, modelo FROM camera
                WHERE (nome LIKE '%$termo_pesquisa%' OR
                      ip LIKE '%$termo_pesquisa%' OR
                      local LIKE '%$termo_pesquisa%' OR
                      marca LIKE '%$termo_pesquisa%' OR
                      modelo LIKE '%$termo_pesquisa%')
                AND nome NOT IN (SELECT nomeCamera FROM preventivaCameratecnico WHERE YEAR(dataHora) = $ano AND MONTH(dataHora) BETWEEN $mesInicio AND $mesFinal)
                ORDER BY ip ASC
                LIMIT $offset, $resultados_por_pagina;";
} else {

    $consulta = "SELECT nome, ip, local, marca, modelo FROM camera
                WHERE nome NOT IN (SELECT nomeCamera FROM preventivaCameratecnico WHERE YEAR(dataHora) = $ano AND MONTH(dataHora) BETWEEN $mesInicio AND $mesFinal)
                ORDER BY ip ASC
                LIMIT $offset, $resultados_por_pagina;";
}

$resultado = mysqli_query($conexao, $consulta);

echo "<table border='1'>";
echo "<tr>";
echo "<th>CAMERA</th>";
echo "<th>IP</th>";
echo "<th>LOCAL</th>";
echo "<th>MARCA</th>";
echo "<th>MODELO</th>";
echo "<th style='width: 100px;'>Detalhes</th>";
echo "</tr>";

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['nome'] . "</td>"; 
    echo "<td>" . $linha['ip'] . "</td>"; 
    echo "<td>" . $linha['local'] . "</td>"; 
    echo "<td>" . $linha['marca'] . "</td>"; 
    echo "<td>" . $linha['modelo'] . "</td>"; 
    echo "<td class='centerVisualizar'><a href='detalhesCamera.php?camera_nome=" . $linha['nome'] . "'>Visualizar</a></td>";
    echo "</tr>";
}

echo "</table>";


$total_resultados = mysqli_num_rows(mysqli_query($conexao, "SELECT * FROM camera WHERE nome NOT IN (SELECT nome FROM preventivaCameratecnico WHERE YEAR(dataHora) = $ano AND MONTH(dataHora) BETWEEN $mesInicio AND $mesFinal)"));
$total_paginas = ceil($total_resultados / $resultados_por_pagina);


echo "<div class='paginacao'>";
for ($pagina = 1; $pagina <= $total_paginas; $pagina++) {
    echo "<a href='?pagina=$pagina'>$pagina</a> ";
}
echo "</div>";

mysqli_close($conexao);
?>
