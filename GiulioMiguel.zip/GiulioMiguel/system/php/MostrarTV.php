<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

$consulta = "SELECT serial, marca, polegadas, local FROM televisao";
$resultado = mysqli_query($conexao, $consulta);

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['serial'] . "</td>";
    echo "<td>" . $linha['marca'] . "</td>";
    echo "<td>" . $linha['polegadas'] . "</td>";
    echo "<td>" . $linha['local'] . "</td>";
    echo "</tr>";
}

mysqli_close($conexao);
?>
