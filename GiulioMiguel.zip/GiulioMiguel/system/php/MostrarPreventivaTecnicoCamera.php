<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

$resultados_por_pagina = 20;

$pagina_atual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

$offset = ($pagina_atual - 1) * $resultados_por_pagina;

if(isset($_GET['search'])){
    $termo_pesquisa = $_GET['search'];
    $consulta = "SELECT 
                    pc.id,
                    pct.fk_Tecnico_id,
                    pct.nomeTecnico,
                    pct.nomeCamera,
                    DATE(pct.dataHora) as dataHora,
                    pc.horaInicio,
                    pc.horaTermino
                FROM 
                    PreventivaCameraTecnico pct
                JOIN 
                    PreventivaCamera pc ON pct.fk_PreventivaCamera_id = pc.id 
                WHERE 
                    pct.nomeTecnico LIKE '%$termo_pesquisa%' OR
                    pct.nomeCamera LIKE '%$termo_pesquisa%' OR
                    pc.horaInicio LIKE '%$termo_pesquisa%' OR
                    pc.horaTermino LIKE '%$termo_pesquisa%' OR
                    DATE(pct.dataHora) LIKE '%$termo_pesquisa%'
                ORDER BY 
                    pc.id DESC
                LIMIT 
                    $offset, $resultados_por_pagina;";
} else {
    $consulta = "SELECT 
                    pc.id,
                    pct.fk_Tecnico_id,
                    pct.nomeTecnico,
                    pct.nomeCamera,
                    DATE(pct.dataHora) as dataHora,
                    pc.horaInicio,
                    pc.horaTermino
                FROM 
                    PreventivaCameraTecnico pct
                JOIN 
                    PreventivaCamera pc ON pct.fk_PreventivaCamera_id = pc.id 
                ORDER BY 
                    pc.id DESC
                LIMIT 
                    $offset, $resultados_por_pagina;";
}

$resultado = mysqli_query($conexao, $consulta);

echo "<table border='1'>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Técnico ID</th>";
echo "<th>Técnico</th>";
echo "<th>Câmera</th>";
echo "<th>Hora Inicio</th>";
echo "<th>Hora Termino</th>";
echo "<th>Data e Hora</th>";
echo "</tr>";

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['id'] . "</td>";
    echo "<td>" . $linha['fk_Tecnico_id'] . "</td>"; 
    echo "<td>" . $linha['nomeTecnico'] . "</td>"; 
    echo "<td>" . $linha['nomeCamera'] . "</td>"; 
    echo "<td>" . $linha['horaInicio'] . "</td>";
    echo "<td>" . $linha['horaTermino'] . "</td>";
    echo "<td>" . $linha['dataHora'] . "</td>";
    echo "</tr>";
}

echo "</table>";

$total_resultados = mysqli_num_rows(mysqli_query($conexao, "SELECT id FROM PreventivaCamera"));
$total_paginas = ceil($total_resultados / $resultados_por_pagina);

echo "<div class='paginacao'>";
for ($pagina = 1; $pagina <= $total_paginas; $pagina++) {
    echo "<a href='?pagina=$pagina'>$pagina</a> ";
}
echo "</div>";

mysqli_close($conexao);
?>
