<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../php/conexao.php');

    $id_tecnico = $_POST['id_tecnico'];
    $nome = $_POST['nome'];
    $cargo = $_POST['cargo'];
    $email = $_POST['email'];
    $nivel = $_POST['nivel'];
    $senha = $_POST['senha']; 
    
    $consulta = "UPDATE tecnico SET nome='$nome', cargo='$cargo', email='$email', nivel='$nivel', senha='$senha' WHERE id=$id_tecnico";

    if (mysqli_query($mysqli, $consulta)) {
        header("Location: ../pages/detalhes.php?id=$id_tecnico");
        exit();
    } else {
        echo "Erro ao atualizar os dados do técnico: " . mysqli_error($mysqli);
    }

    mysqli_close($conexao);
} else {
    header("Location: index.php");
    exit();
}
?>
