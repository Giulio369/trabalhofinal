<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

if(isset($_GET['id'])) {
    $id_tecnico = $_GET['id'];
    
    $consulta = "SELECT nome, cargo, email, nivel, senha FROM tecnico WHERE id = $id_tecnico";
    
    $consultaPreventivasCameras = "SELECT COUNT(*) AS preventivas_cameras_realizadas FROM preventivacameratecnico WHERE fk_tecnico_id = $id_tecnico";
    
    $consultaPreventivasTelevisao = "SELECT COUNT(*) AS preventivas_televisao_realizadas FROM preventivatelevisaotecnico WHERE fk_tecnico_id = $id_tecnico";
    
    $resultadoDetalhes = mysqli_query($conexao, $consulta);
    
    $resultadoPreventivasCameras = mysqli_query($conexao, $consultaPreventivasCameras);
    
    $resultadoPreventivasTelevisao = mysqli_query($conexao, $consultaPreventivasTelevisao);
    
    if(mysqli_num_rows($resultadoDetalhes) > 0) {
        $tecnico = mysqli_fetch_assoc($resultadoDetalhes);
        
        $dadosPreventivasCameras = mysqli_fetch_assoc($resultadoPreventivasCameras);
        $preventivas_cameras_realizadas = $dadosPreventivasCameras['preventivas_cameras_realizadas'];
        
        $dadosPreventivasTelevisao = mysqli_fetch_assoc($resultadoPreventivasTelevisao);
        $preventivas_televisao_realizadas = $dadosPreventivasTelevisao['preventivas_televisao_realizadas'];
        
        echo "<h2><strong>Informações Tecnico </strong></h2>";
        echo "<p><strong>Nome:</strong> " . $tecnico['nome'] . "</p>";
        echo "<p><strong>Cargo:</strong> " . $tecnico['cargo'] . "</p>";
        echo "<p><strong>Email:</strong> " . $tecnico['email'] . "</p>";
        echo "<p><strong>Nível:</strong> " . $tecnico['nivel'] . "</p>";
        echo "<p><strong>Senha:</strong> " . $tecnico['senha'] . "</p>";
        echo "<p><strong>Preventivas de Câmeras Realizadas:</strong> " . $preventivas_cameras_realizadas . "</p>";
        echo "<p><strong>Preventivas de Televisão Realizadas:</strong> " . $preventivas_televisao_realizadas . "</p>";
       
        echo "<div class='containerBotoes'>";
        echo "<a href='editar.php?id=" . $id_tecnico . "'>";
        echo "<button class='botaoPequeno'>Editar</button>";
        echo "</a>";
        echo "<a href='excluir.php?id=" . $id_tecnico . "'>";
        echo "<button class='botaoPequeno'>Excluir</button>";
        echo "</a>";

        echo "</div>";
    } else {
        echo "Nenhum técnico encontrado com o ID fornecido.";
    }
} else {
    echo "ID do técnico não especificado.";
}

mysqli_close($conexao);
?>
