<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}

$email = $_POST['email'];
$nome = $_POST['nome'];
$cargo = $_POST['cargo'];
$nivel = $_POST['nivel'];
$senha = $_POST['senha'];
$confirmPassword = $_POST['confirmPassword'];


$sql = "INSERT INTO tecnico (cargo, email, nome, nivel, senha) VALUES ('$cargo ', '$email', '$nome', '$nivel', '$senha')";

if (mysqli_query($conexao, $sql)) {
        echo '<script>alert("Tecnico Adicionado!");</script>';
        header("Location: ../pages/AdicionarTecnico.php");
} else {
    header("Location: ../pages/AdicionarTecnico.php");
    echo '<script>alert("Erro inesperado.");</script>';
    exit(); 
}

mysqli_close($conexao);
?>
