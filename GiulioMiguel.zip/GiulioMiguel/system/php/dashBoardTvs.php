<?php
$servername = "localhost";
$username = "root";
$password = "@admin"; 
$database = "sgpn"; 

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

include ('ControlarCiclo.php');

$sql_cadastradas = "SELECT COUNT(*) AS total_cadastradas FROM televisao";
$result_cadastradas = $conn->query($sql_cadastradas);

$sql_pendentes = "SELECT COUNT(*) AS total_pendentes FROM televisao WHERE serial NOT IN (SELECT serialTV FROM preventivatelevisaotecnico WHERE YEAR(dataHora) = $ano AND MONTH(dataHora) BETWEEN $mesInicio AND $mesFinal)";
$result_pendentes = $conn->query($sql_pendentes);

if ($result_cadastradas->num_rows > 0 && $result_pendentes->num_rows > 0) {
    $row_cadastradas = $result_cadastradas->fetch_assoc();
    $total_cadastradas = $row_cadastradas["total_cadastradas"];

    $row_pendentes = $result_pendentes->fetch_assoc();
    $total_pendentes = $row_pendentes["total_pendentes"];

    echo $total_cadastradas . "," . $total_pendentes;
} else {
    echo "0,0"; 
}

$conn->close();
?>
