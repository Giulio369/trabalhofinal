<?php
if (!isset($_SESSION)) {
    session_start();
}

if (isset($_SESSION['nivel'])) {
   if ($_SESSION['nivel'] == 0) {
        echo '<script>document.getElementById("link-admin").style.display = "none";</script>';
        echo '<script>document.getElementById("adicionarCam").style.display = "none";</script>';
        echo '<script>document.getElementById("EditarExcluir").style.display = "none";</script>';

        exit; 
    } 
} 
?>
