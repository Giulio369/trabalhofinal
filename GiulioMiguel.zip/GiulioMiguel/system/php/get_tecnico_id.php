<?php 
if(isset($_GET['id'])) {
    $id_tecnico = $_GET['id'];
    
    $consulta = "SELECT nome, cargo, email, nivel, senha FROM tecnico WHERE id = $id_tecnico";
    
    $resultado = mysqli_query($mysqli, $consulta);
    
    if(mysqli_num_rows($resultado) > 0) {
        $tecnico = mysqli_fetch_assoc($resultado);
    } else {
        echo "Nenhum técnico encontrado com o ID fornecido.";
        exit(); 
    }
} else {
    echo "ID do técnico não especificado.";
    exit(); 
}

mysqli_close($mysqli);
?>