<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}

if (!empty($_POST)) { 
    $local = $_POST['local'];
    $nome = $_POST['nome'];
    $ip = $_POST['ip'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $dataInstalacao = $_POST['dataInstalacao'];

    $sql_verificar_nome = "SELECT * FROM camera WHERE nome = '$nome'";
    $resultado_verificar_nome = mysqli_query($conexao, $sql_verificar_nome);

    if (mysqli_num_rows($resultado_verificar_nome) > 0) {
        echo '<script>alert("Já existe uma câmera com o mesmo nome.");</script>';
    } else {
        $sql = "INSERT INTO camera (local, nome, ip, marca, modelo, dataInstalacao) VALUES ('$local', '$nome', '$ip', '$marca', '$modelo', '$dataInstalacao')";

        if (mysqli_query($conexao, $sql)) {
            echo '<script>alert("Câmera adicionada com sucesso!");</script>';
        } else {
            echo '<script>alert("Erro ao adicionar a câmera.");</script>';
        }
    }
}

mysqli_close($conexao);
?>
