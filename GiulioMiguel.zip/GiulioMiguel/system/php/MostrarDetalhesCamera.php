<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

if(isset($_GET['camera_nome'])) {
    $nome = mysqli_real_escape_string($conexao, $_GET['camera_nome']); 
    
   
    $consulta = "SELECT local, nome, ip, marca, modelo, dataInstalacao FROM camera WHERE nome = '$nome'";
    $consultaPreventivasCameras = "SELECT COUNT(*) AS Preventivas_Camera FROM preventivacameratecnico WHERE nomeCamera = '$nome'";
    
    $resultadoDetalhes = mysqli_query($conexao, $consulta);
    $resultadoPreventivasCameras = mysqli_query($conexao, $consultaPreventivasCameras);
    if(mysqli_num_rows($resultadoDetalhes) > 0) {
      
        $camera = mysqli_fetch_assoc($resultadoDetalhes);
        $dadosPreventivasCameras = mysqli_fetch_assoc($resultadoPreventivasCameras);
        $preventivas_cameras_realizadas = $dadosPreventivasCameras['Preventivas_Camera'];
        
       
        echo "<h2><strong>Informações da Câmera</strong></h2>";
        echo "<p><strong>Câmera:</strong> " . $camera['nome'] . "</p>";
        echo "<p><strong>Local:</strong> " . $camera['local'] . "</p>";
        echo "<p><strong>IP:</strong> " . $camera['ip'] . "</p>";
        echo "<p><strong>Marca:</strong> " . $camera['marca'] . "</p>";
        echo "<p><strong>Modelo:</strong> " . $camera['modelo'] . "</p>";
        echo "<p><strong>Data de Instalação:</strong> " . $camera['dataInstalacao'] . "</p>";
        echo "<p><strong>Preventivas Recebidas:</strong> " . $preventivas_cameras_realizadas . "</p>";
       
        echo "<div id='EditarExcluir' class='containerBotoes'>";
        echo "<a href='editarCamera.php?camera_nome=" . $nome . "'>";
        echo "<button class='botaoPequeno'>Editar</button>";
        echo "</a>";
        echo "<a href='excluirCamera.php?camera_nome=" . $nome . "'>";
        echo "<button class='botaoPequeno'>Excluir</button>";
        echo "</a>";

        echo "</div>";
    } else {
        
        echo "Nenhuma câmera encontrada com o nome fornecido.";
    }
} else {
    echo "Nome da câmera não especificado.";
}


mysqli_close($conexao);
?>
