<?php

$conn = new mysqli('localhost', 'usuario', 'senha', 'nome_do_banco_de_dados');

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$sql = "SELECT YEARWEEK(data) AS week, COUNT(*) AS count FROM sua_tabela GROUP BY week";
$result = $conn->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($data);
?>
