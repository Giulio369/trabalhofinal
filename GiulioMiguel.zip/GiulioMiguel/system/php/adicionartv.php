<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}

if (!empty($_POST)) { 
    $serial = $_POST['serial'];
    $marca = $_POST['marca'];
    $polegadas = $_POST['polegadas'];
    $local = $_POST['local'];
    $dataInstalacao = $_POST['dataInstalacao'];

    if (strpos($serial, ' ') !== false) {
        echo '<script>alert("O serial não pode conter espaços em branco.");</script>';
    } else {
        $sql_verificar_serial = "SELECT * FROM televisao WHERE serial = ?";
        $stmt_verificar_serial = mysqli_prepare($conexao, $sql_verificar_serial);
        mysqli_stmt_bind_param($stmt_verificar_serial, "s", $serial);
        mysqli_stmt_execute($stmt_verificar_serial);
        $resultado_verificar_serial = mysqli_stmt_get_result($stmt_verificar_serial);

        if (mysqli_num_rows($resultado_verificar_serial) > 0) {
            echo '<script>alert("Já existe uma televisão com o mesmo serial.");</script>';
        } else {
            $sql = "INSERT INTO televisao (serial, marca, polegadas, local, dataInstalacao) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conexao, $sql);
            mysqli_stmt_bind_param($stmt, "ssiss", $serial, $marca, $polegadas, $local, $dataInstalacao);

            if (mysqli_stmt_execute($stmt)) {
                echo '<script>alert("TV adicionada com sucesso!");</script>';
            } else {
                echo '<script>alert("Erro ao adicionar a TV.");</script>';
            }
        }
    }
}

mysqli_close($conexao);
?>
