<?php
$servername = "localhost"; 
$username = "root"; 
$password = "@admin";
$database = "sgpn"; 

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$sql_preventivas_diarias = "SELECT DATE(dataHora) AS dia, COUNT(*) AS total_preventivas FROM preventivaCameratecnico WHERE dataHora >= CURDATE() - INTERVAL 30 DAY GROUP BY DATE(dataHora)";
$result_preventivas_diarias = $conn->query($sql_preventivas_diarias);

$preventivas_diarias = array();

while($row = $result_preventivas_diarias->fetch_assoc()) {
    $preventivas_diarias[$row['dia']] = $row['total_preventivas'];
}

echo json_encode($preventivas_diarias);

$conn->close();
?>
