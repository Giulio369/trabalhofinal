<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

$resultados_por_pagina = 20;

$pagina_atual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

$offset = ($pagina_atual - 1) * $resultados_por_pagina;

if(isset($_GET['search'])){
    $termo_pesquisa = $_GET['search'];
    $consulta = "SELECT serial, marca, polegadas, local FROM televisao
                WHERE serial LIKE '%$termo_pesquisa%' OR
                      marca LIKE '%$termo_pesquisa%' OR
                      polegadas LIKE '%$termo_pesquisa%' OR
                      local LIKE '%$termo_pesquisa%'
                ORDER BY local ASC
                LIMIT $offset, $resultados_por_pagina;";
} else {
    $consulta = "SELECT serial, marca, polegadas, local FROM televisao
                ORDER BY local ASC
                LIMIT $offset, $resultados_por_pagina;";
}


$resultado = mysqli_query($conexao, $consulta);


echo "<table border='1'>";
echo "<tr>";
echo "<th>SERIAL</th>";
echo "<th>MARCA</th>";
echo "<th>POLEGADAS</th>";
echo "<th>LOCAL</th>";
echo "<th style='width: 100px;'>Detalhes</th>";
echo "</tr>";

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['serial'] . "</td>"; 
    echo "<td>" . $linha['marca'] . "</td>"; 
    echo "<td>" . $linha['polegadas'] . "</td>"; 
    echo "<td>" . $linha['local'] . "</td>"; 
    echo "<td class='centerVisualizar'><a href='detalhesTv.php?televisao_serial=" . $linha['serial'] . "'>Visualizar</a></td>"; 
    echo "</tr>";
}

echo "</table>";

$total_resultados = mysqli_num_rows(mysqli_query($conexao, "SELECT * FROM televisao"));
$total_paginas = ceil($total_resultados / $resultados_por_pagina);

echo "<div class='paginacao'>";
for ($pagina = 1; $pagina <= $total_paginas; $pagina++) {
    echo "<a href='?pagina=$pagina'>$pagina</a> ";
}
echo "</div>";

mysqli_close($conexao);
?>
