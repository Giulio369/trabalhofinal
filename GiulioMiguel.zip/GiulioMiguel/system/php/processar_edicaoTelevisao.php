<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../php/conexao.php');

    $televisao_serial_antigo = $_POST['televisao_serial']; 
    $televisao_serial_novo = $_POST['serial']; 
    $local = $_POST['local'];
    $marca = $_POST['marca'];
    $polegadas = $_POST['polegadas'];
    $dataInstalacao = $_POST['dataInstalacao'];

    $dataInstalacaoFormatada = date('Y-m-d', strtotime($dataInstalacao));
    
    $consulta = "UPDATE televisao SET serial='$televisao_serial_novo', local='$local', marca='$marca', polegadas='$polegadas', dataInstalacao='$dataInstalacaoFormatada' WHERE serial='$televisao_serial_antigo'";
    
    if (mysqli_query($mysqli, $consulta)) {
        header("Location: ../pages/detalhesTv.php?televisao_serial=$televisao_serial_novo");
        exit();
    } else {
        echo "Erro ao atualizar os dados da televisão: " . mysqli_error($mysqli);
    }

    mysqli_close($mysqli);
} else {

    header("Location: index.php");
    exit();
}
?>
