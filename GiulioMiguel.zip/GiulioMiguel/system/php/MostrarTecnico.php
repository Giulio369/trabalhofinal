<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}
$resultados_por_pagina = 20;

$pagina_atual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

$offset = ($pagina_atual - 1) * $resultados_por_pagina;

if(isset($_GET['search'])){
    $termo_pesquisa = $_GET['search'];
    $consulta = "SELECT nome, cargo, email, id, nivel, senha FROM tecnico
                WHERE nome LIKE '%$termo_pesquisa%' OR
                cargo LIKE '%$termo_pesquisa%' OR
                email LIKE '%$termo_pesquisa%' OR
                id LIKE '%$termo_pesquisa%' OR
                nivel LIKE '%$termo_pesquisa%'
                ORDER BY id ASC
                LIMIT $offset, $resultados_por_pagina;";
} else {
    $consulta = "SELECT nome, cargo, email, id, nivel, senha FROM tecnico
                ORDER BY id ASC
                LIMIT $offset, $resultados_por_pagina;";
}

$resultado = mysqli_query($conexao, $consulta);


echo "<table border='1'>";
echo "<tr>";
echo "<th>NOME</th>";
echo "<th>CARGO</th>";
echo "<th>EMAIL</th>";
echo "<th>ID</th>";
echo "<th>NIVEL</th>";
echo "<th>SENHA</th>";
echo "<th style='width: 100px;'>Detalhes</th>";
echo "</tr>";

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['nome'] . "</td>"; 
    echo "<td>" . $linha['cargo'] . "</td>"; 
    echo "<td>" . $linha['email'] . "</td>"; 
    echo "<td>" . $linha['id'] . "</td>";
    echo "<td>" . $linha['nivel'] . "</td>"; 
    echo "<td>" . $linha['senha'] . "</td>";
    echo "<td class='centerVisualizar'><a href='detalhes.php?id=" . $linha['id'] . "'>Visualizar</a></td>"; 
    echo "</tr>";
}

echo "</table>";

$total_resultados = mysqli_num_rows(mysqli_query($conexao, "SELECT * FROM tecnico"));
$total_paginas = ceil($total_resultados / $resultados_por_pagina);

echo "<div class='paginacao'>";
for ($pagina = 1; $pagina <= $total_paginas; $pagina++) {
    echo "<a href='?pagina=$pagina'>$pagina</a> ";
}
echo "</div>";

mysqli_close($conexao);
?>
