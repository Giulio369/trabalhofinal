<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar ao MySQL: " . mysqli_connect_error();
    exit();
}

$resultados_por_pagina = 20;

$pagina_atual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

$offset = ($pagina_atual - 1) * $resultados_por_pagina;

if(isset($_GET['search'])){
    $termo_pesquisa = $_GET['search'];
    $consulta = "SELECT 
                    pc.id,
                    pct.fk_Tecnico_id,
                    pct.nomeTecnico,
                    pct.serialTv,
                    pc.tela,
                    pc.cabeamento,
                    pc.controles,
                    pc.configuracao,
                    pc.observacao,
                    pct.dataHora
                FROM 
                    PreventivaTelevisaoTecnico pct
                JOIN 
                    PreventivaTelevisao pc ON pct.fk_PreventivaTelevisao_id = pc.id
                WHERE 
                    pct.nomeTecnico LIKE '%$termo_pesquisa%' OR
                    pct.serialTv LIKE '%$termo_pesquisa%' OR
                    pc.tela LIKE '%$termo_pesquisa%' OR
                    pc.cabeamento LIKE '%$termo_pesquisa%' OR
                    pc.controles LIKE '%$termo_pesquisa%' OR
                    pc.configuracao LIKE '%$termo_pesquisa%' OR
                    pc.observacao LIKE '%$termo_pesquisa%' OR
                    pct.dataHora LIKE '%$termo_pesquisa%'
                ORDER BY 
                    pc.id DESC
                LIMIT 
                    $offset, $resultados_por_pagina;";
} else {
    $consulta = "SELECT 
                    pc.id,
                    pct.fk_Tecnico_id,
                    pct.nomeTecnico,
                    pct.serialTv,
                    pc.tela,
                    pc.cabeamento,
                    pc.controles,
                    pc.configuracao,
                    pc.observacao,
                    pct.dataHora
                FROM 
                    PreventivaTelevisaoTecnico pct
                JOIN 
                    PreventivaTelevisao pc ON pct.fk_PreventivaTelevisao_id = pc.id
                ORDER BY 
                    pc.id DESC
                LIMIT 
                    $offset, $resultados_por_pagina;";
}

$resultado = mysqli_query($conexao, $consulta);

echo "<table border='1'>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Técnico ID</th>";
echo "<th>Técnico</th>";
echo "<th>Televisao (Serial)</th>";
echo "<th>Tela</th>";
echo "<th>Cabeamento</th>";
echo "<th>Controles</th>";
echo "<th>Configurações</th>";
echo "<th>Observacao</th>";
echo "<th>Data e Hora</th>";
echo "</tr>";

while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $linha['id'] . "</td>";
    echo "<td>" . $linha['fk_Tecnico_id'] . "</td>"; 
    echo "<td>" . $linha['nomeTecnico'] . "</td>"; 
    echo "<td>" . $linha['serialTv'] . "</td>"; 
    echo "<td>" . $linha['tela'] . "</td>";
    echo "<td>" . $linha['cabeamento'] . "</td>";
    echo "<td>" . $linha['controles'] . "</td>";
    echo "<td>" . $linha['configuracao'] . "</td>";
    echo "<td>" . $linha['observacao'] . "</td>";
    echo "<td>" . $linha['dataHora'] . "</td>";
    echo "</tr>";
}

echo "</table>";

$total_resultados = mysqli_num_rows(mysqli_query($conexao, "SELECT id FROM PreventivaTelevisao"));
$total_paginas = ceil($total_resultados / $resultados_por_pagina);

echo "<div class='paginacao'>";
for ($pagina = 1; $pagina <= $total_paginas; $pagina++) {
    echo "<a href='?pagina=$pagina'>$pagina</a> ";
}
echo "</div>";

mysqli_close($conexao);
?>
