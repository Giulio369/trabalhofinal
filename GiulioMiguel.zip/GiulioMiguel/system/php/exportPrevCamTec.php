<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$sql = "SELECT 
pc.id,
pct.fk_Tecnico_id,
pct.nomeTecnico,
pct.nomeCamera,
DATE(pct.dataHora) as dataHora,
pc.horaInicio,
pc.horaTermino
FROM 
PreventivaCameraTecnico pct
JOIN 
PreventivaCamera pc ON pct.fk_PreventivaCamera_id = pc.id 
ORDER BY 
pc.id DESC;";
$result = $conn->query($sql);

header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename="dados_tecnico.csv"');

$output = fopen('php://output', 'w');

fputcsv($output, array('Numero da Preventiva ', 'Numero do Tecnico', 'Nome do Tecnico', 'Camera','Data', 'Inicio da Preventiva', 'Termino da Preventiva'));

while ($row = $result->fetch_assoc()) {
    $cleaned_row = array_map(function($value) {
        return str_replace(array("\r", "\n", "\r\n", "\n\r", ","), ' ', $value);
    }, $row);

    fputcsv($output, $cleaned_row);
}

fclose($output);
?>
