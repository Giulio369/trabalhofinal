<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}

$serial = $_SESSION['serialTv'];
if(isset($_POST['tela'])) {
    $tela = $_POST['tela'];
    $controles = $_POST['controles'];
    $configuracao = $_POST['configuracao'];
    $cabeamento = $_POST['cabeamento'];
    $observacao = $_POST['observacao'];

    if(strlen($serial) == 0) {
        echo '<script>alert("TV não especificada!!");</script>';
    } else {
        $serial = $conexao->real_escape_string($serial);

        $sql_code = "SELECT * FROM televisao WHERE serial = '$serial'";
        $sql_query = $conexao->query($sql_code) or die("Falha na execução do código SQL: " . $conexao->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            $idTecnico = $_SESSION['id'];
            $NomeTecnico = $_SESSION['nome'];


            $sql_tv = "INSERT INTO PreventivaTelevisao (tela, controles, configuracao, cabeamento, observacao) 
                           VALUES ('$tela', '$controles', '$configuracao', '$cabeamento', '$observacao')";
            mysqli_query($conexao, $sql_tv) or die("Erro ao inserir na tabela camera: " . mysqli_error($conexao));


            $idPreventiva = mysqli_insert_id($conexao);
            $horaInicio = $_SESSION['horaInicio'];
            $horaTermino = date('H:i:s'); // Pega a hora atual

            $sql_preventiva = "INSERT INTO PreventivaTelevisaoTecnico (fk_PreventivaTelevisao_id, fk_Tecnico_id, serialTv, nomeTecnico, horaInicio, horaTermino, dataHora) 
                               VALUES ('$idPreventiva', '$idTecnico', '$serial', '$NomeTecnico', '$horaInicio', '$horaTermino', now())";
            mysqli_query($conexao, $sql_preventiva) or die("Erro ao inserir na tabela PreventivaTelevisaoTecnico: " . mysqli_error($conexao));
            $_SESSION['TvRealizada'] = $_SESSION['serialTv'];
            unset($_SESSION['serialTv']);
            header("Location: ../pages/preventivaTvRealizada.php");
            exit(); 
        } else {
            echo '<script>alert("TV Inexistente! Tente novamente!");</script>';
            header("Location: ../pages/preventivaTvNaoRealizada.php");
        }
    }
}

mysqli_close($conexao);
?>
