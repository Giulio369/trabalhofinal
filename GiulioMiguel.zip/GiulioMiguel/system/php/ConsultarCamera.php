<?php
include('conexao.php');

if(isset($_POST['nome'])) {

    if(strlen($_POST['nome']) == 0) {
        echo '<script>alert("Câmera não especificada!!");</script>';
    } else {

        $nome = $mysqli->real_escape_string($_POST['nome']);

        $sql_code = "SELECT * FROM camera WHERE nome = '$nome'";
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            

            header("Location: preventivaRealizada.php");

        } else {
            echo '<script>alert("Camera Inexistente! Tente novamente!");</script>';
        }

    }

}
?>