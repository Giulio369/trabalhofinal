<?php
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$sql = "SELECT Cargo, Email, Nome, id, nivel, senha FROM tecnico";
$result = $conn->query($sql);

header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename="dados_tecnico.csv"');

$output = fopen('php://output', 'w');

fputcsv($output, array('Cargo', 'Email', 'Nome', 'ID', 'Nível', 'Senha'));

while ($row = $result->fetch_assoc()) {
    $cleaned_row = array_map(function($value) {
        return str_replace(array("\r", "\n", "\r\n", "\n\r", ","), ' ', $value);
    }, $row);

    fputcsv($output, $cleaned_row);
}

fclose($output);
?>
