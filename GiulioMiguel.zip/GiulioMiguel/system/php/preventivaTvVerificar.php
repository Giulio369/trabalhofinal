<?php 
session_start();
date_default_timezone_set('America/Sao_Paulo');
$host = 'localhost';
$usuario = 'root';
$senha = '@admin';
$banco = 'sgpn';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro de conexão: ' . mysqli_connect_error());
}
if(isset($_POST['serial'])) {
    $serialTv = $_POST['serial'];
    $sql_code = "SELECT * FROM televisao WHERE serial = '$serialTv'";
      $sql_query = $conexao->query($sql_code) or die("Falha na execução do código SQL: " . $conexao->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            $sql_codePreventiva = "SELECT COUNT(*) AS preventiva_realizadas FROM preventivatelevisaotecnico WHERE serialTv = '$serialTv'";
            $QuantidadePreventiva = $conexao->query($sql_codePreventiva) or die("Falha na execução do código SQL: " . $conexao->error);
            $row = $QuantidadePreventiva->fetch_assoc(); // Obtém a primeira linha do resultado
            if ($row['preventiva_realizadas'] == 0 ) {            
                $horaInicio = date('H:i:s'); // Pega a hora atual
                $_SESSION['serialTv'] = $_POST['serial'];
                $_SESSION['horaInicio'] = $horaInicio;
                header("Location: ../pages/preventivaTv.php");
            } else {
                echo '<script>alert("Preventiva já realizada para essa câmera!");</script>';
        
            }
        } else {
            echo '<script>alert("Câmera Inexistente! Tente novamente!");</script>';
           // header("Location: ../pages/preventivaCameraVerificar.php");
        }
}

?>