CREATE DATABASE  IF NOT EXISTS `sgpn` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `sgpn`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sgpn
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `nome` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `cargo` varchar(30) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `nivel` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administradorcamera`
--

DROP TABLE IF EXISTS `administradorcamera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administradorcamera` (
  `fk_Administrador_id` int NOT NULL,
  `fk_Camera_nome` varchar(20) NOT NULL,
  `dataHora` datetime DEFAULT NULL,
  PRIMARY KEY (`fk_Administrador_id`,`fk_Camera_nome`),
  KEY `FK_AdministradorCamera_2` (`fk_Camera_nome`),
  CONSTRAINT `FK_AdministradorCamera_1` FOREIGN KEY (`fk_Administrador_id`) REFERENCES `administrador` (`id`),
  CONSTRAINT `FK_AdministradorCamera_2` FOREIGN KEY (`fk_Camera_nome`) REFERENCES `camera` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradorcamera`
--

LOCK TABLES `administradorcamera` WRITE;
/*!40000 ALTER TABLE `administradorcamera` DISABLE KEYS */;
/*!40000 ALTER TABLE `administradorcamera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administradortelevisao`
--

DROP TABLE IF EXISTS `administradortelevisao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administradortelevisao` (
  `fk_Administrador_id` int NOT NULL,
  `fk_Televisao_serial` varchar(100) NOT NULL,
  PRIMARY KEY (`fk_Administrador_id`,`fk_Televisao_serial`),
  KEY `FK_AdministradorTelevisao_2` (`fk_Televisao_serial`),
  CONSTRAINT `FK_AdministradorTelevisao_1` FOREIGN KEY (`fk_Administrador_id`) REFERENCES `administrador` (`id`),
  CONSTRAINT `FK_AdministradorTelevisao_2` FOREIGN KEY (`fk_Televisao_serial`) REFERENCES `televisao` (`serial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradortelevisao`
--

LOCK TABLES `administradortelevisao` WRITE;
/*!40000 ALTER TABLE `administradortelevisao` DISABLE KEYS */;
/*!40000 ALTER TABLE `administradortelevisao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cadastrotecnico`
--

DROP TABLE IF EXISTS `cadastrotecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cadastrotecnico` (
  `fk_Administrador_id` int NOT NULL,
  `fk_Tecnico_id` int NOT NULL,
  `dataHora` datetime DEFAULT NULL,
  PRIMARY KEY (`fk_Administrador_id`,`fk_Tecnico_id`),
  KEY `FK_CadastroTecnico_2` (`fk_Tecnico_id`),
  CONSTRAINT `FK_CadastroTecnico_1` FOREIGN KEY (`fk_Administrador_id`) REFERENCES `administrador` (`id`),
  CONSTRAINT `FK_CadastroTecnico_2` FOREIGN KEY (`fk_Tecnico_id`) REFERENCES `tecnico` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cadastrotecnico`
--

LOCK TABLES `cadastrotecnico` WRITE;
/*!40000 ALTER TABLE `cadastrotecnico` DISABLE KEYS */;
/*!40000 ALTER TABLE `cadastrotecnico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `camera`
--

DROP TABLE IF EXISTS `camera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camera` (
  `local` varchar(100) DEFAULT NULL,
  `nome` varchar(20) NOT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `marca` varchar(20) DEFAULT NULL,
  `modelo` varchar(20) DEFAULT NULL,
  `DataInstalacao` date DEFAULT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `camera`
--

LOCK TABLES `camera` WRITE;
/*!40000 ALTER TABLE `camera` DISABLE KEYS */;
INSERT INTO `camera` VALUES ('qualquer coisa ','a ','  ',' ',' ','2025-05-13'),('Sala de Reunião','Camera1','192.168.0.101','MarcaA','ModeloX','2022-01-10'),('Recepção','Camera2','192.168.0.102','MarcaB','ModeloY','2022-02-15'),('Escritório','Camera3','192.168.0.103','MarcaC','ModeloZ','2022-03-20'),('Corredor','Camera4','192.168.0.104','MarcaD','ModeloW','2022-04-25'),('Predio 100','P100FIX012','172.16.100.12','VIVOTEK','IB9367-HT','2023-01-02'),('Predio 100','P100FIX013','172.16.100.13','VIVOTEK','IB9367-HT','2023-01-04'),('Predio 100','P100FIX016','172.16.100.16','VIVOTEK','IB9367-HT','2023-01-10'),('Predio 20','P20FIX001','172.16.20.1','VIVOTEK','IB9367-HT','2023-01-11'),('Predio 20','P20FIX002','172.16.20.2','VIVOTEK','IB9367-HT','2023-01-12'),('Predio 20','P20FIX003','172.16.20.3','VIVOTEK','IB9367-HT','2023-01-13'),('Predio 20','P20FIX004','172.16.20.4','VIVOTEK','IB9367-HT','2023-01-14'),('Predio 20','P20FIX005','172.16.20.5','VIVOTEK','IB9367-HT','2023-01-15'),('Predio 20','P20FIX007','172.16.20.7','VIVOTEK','IB9367-HT','2023-01-17'),('Predio 20','P20FIX008','172.16.20.8','VIVOTEK','IB9367-HT','2023-01-18'),('Predio 20','P20FIX009','172.16.20.9','VIVOTEK','IB9367-HT','2023-01-19'),('Predio 20','P20FIX010','172.16.20.10','VIVOTEK','IB9367-HT','2023-01-20'),('Predio 40 ','P40FIX004','172.16.40.4','VIVOTEK','ASK123','2018-01-18'),('Predio 90','P90FIX001','172.16.90.3','VIVOTEK','IB9367-HT','2023-01-01'),('Predio 90','P90FIX003','172.16.90.3','VIVOTEK','IB9367-HT','2024-04-20'),('Predio 90','P90FIX005','172.16.90.5','VIVOTEK','IB9367-HT','2023-01-05'),('Predio 90','P90FIX007','172.16.90.7','VIVOTEK','IB9367-HT','2023-01-09');
/*!40000 ALTER TABLE `camera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preventivacamera`
--

DROP TABLE IF EXISTS `preventivacamera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preventivacamera` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patchCord` varchar(100) DEFAULT NULL,
  `cabo` varchar(100) DEFAULT NULL,
  `vidro` varchar(100) DEFAULT NULL,
  `acrilico` varchar(100) DEFAULT NULL,
  `lente` varchar(100) DEFAULT NULL,
  `foco` varchar(100) DEFAULT NULL,
  `qualidade` varchar(100) DEFAULT NULL,
  `observacao` varchar(300) DEFAULT NULL,
  `horaInicio` time DEFAULT NULL,
  `horaTermino` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preventivacamera`
--

LOCK TABLES `preventivacamera` WRITE;
/*!40000 ALTER TABLE `preventivacamera` DISABLE KEYS */;
INSERT INTO `preventivacamera` VALUES (1,'Ok','Ok','Ok','Ok','','Ok','ok','Preventiva realizada',NULL,NULL),(2,'Tudo certo','Pouco danificado','Quebrado','Limpo','','Ajustado','Ajustada','Realizada preventiva',NULL,NULL),(3,'ok','Pouco danificado','Ok','Limpo','','Ajustado','Ok','Preventiva realizada',NULL,NULL),(4,'ok','ok','ok','Ok','','Ok','Ok','Preventiva realizada',NULL,NULL),(5,'ok','Ok','Ok','Ok','','Ajustado','Perfeito','Foi realizado a preventiva, porém a câmera encontra-se em um estado deplorável!',NULL,NULL),(6,'Ok','Ok','Ok','Ok','','Ok','Ok','Preventiva realizada',NULL,NULL),(7,'Ok','Ok','Ok','Ok','','Ok','Ok','Preventiva realizada',NULL,NULL),(8,'Ok','Ok','Ok','Ok','','Ok','Ok','Preventiva realizada',NULL,NULL),(9,'Ok','Ok','Ok','Ok','','Ok','Ok','Preventiva realizada',NULL,NULL),(10,'Ok','Ok','Ok','Ok','','Ajustado','Ajustada','Foi realizado a preventiva, porém a câmera encontra-se em um estado deplorável!',NULL,NULL),(11,'Ok','ok','ok','ok','','ok','ok','ok',NULL,NULL),(12,'Ok','Ok','Ok','ok','','ok','ok','ok',NULL,NULL),(13,' ',' ','  ','  ',' ',' ',' ',' ','20:26:21','20:30:09'),(14,' ',' ',' ',' ',' ',' ',' ',' ','20:30:44','20:30:51'),(15,'  ',' ',' ',' ',' ',' ',' ',' ','20:31:37','20:31:46'),(16,' ',' ','  ',' ',' ',' ',' ',' ','20:33:00','20:33:10'),(17,' ',' ',' ',' ',' ',' ',' ',' ','20:33:46','19:33:57'),(18,' ',' ',' ',' ',' ',' ',' ',' ','20:45:21','20:46:56'),(19,' ',' ',' ',' ',' ',' ',' ',' ','19:46:18','19:46:29'),(20,' ',' ',' ',' ',' ',' ',' ',' ','19:49:21','19:49:33'),(21,' ',' ',' ',' ',' ',' ',' ',' ','20:56:37','20:57:19'),(22,' ',' ',' ',' ',' ',' ',' ',' ','20:58:03','20:58:11'),(23,' ',' ',' ',' ',' ',' ',' ',' ','21:46:22','21:46:28'),(24,' ',' ',' ',' ',' ',' ',' ',' ','15:29:46','15:29:55'),(25,' ',' ',' ',' ',' ',' ',' ',' ','22:58:00','22:58:08'),(26,' ',' ',' ',' ',' ',' ',' ',' ','02:43:42','02:43:51'),(27,' ',' ',' ',' ',' ',' ',' ',' ','23:17:08','23:17:20'),(28,' ',' ',' ',' ',' ',' ',' ',' ','18:35:13','18:35:33'),(29,' ok',' ok','ok','ok','ok','ok','ok','ok','18:38:14','18:38:24'),(30,' ok',' ok','ok','ok','ok','ok','ok','ok',NULL,NULL),(31,' ',' ',' ',' ',' ',' ',' ',' ',NULL,NULL),(32,' ',' ',' ',' ',' ',' ',' ',' ',NULL,NULL),(33,' ',' ',' ',' ',' ',' ',' ',' ',NULL,NULL),(34,' ',' ',' ',' ',' ',' ',' ',' ',NULL,NULL),(35,'  b','   ','  ','  ','  ','  ','  ','  ',NULL,NULL),(36,' ',' ',' ',' ',' ',' ',' ',' ',NULL,NULL),(37,' ok',' ok','ok','ok','ok','ok','ok','ok',NULL,NULL),(38,' ok',' ok',' ',' ',' ',' ',' ',' ',NULL,NULL),(39,'opk','ok','ok','ok','ok','ok','ok','ok',NULL,NULL);
/*!40000 ALTER TABLE `preventivacamera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preventivacameratecnico`
--

DROP TABLE IF EXISTS `preventivacameratecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preventivacameratecnico` (
  `fk_Tecnico_id` int DEFAULT NULL,
  `fk_PreventivaCamera_id` int DEFAULT NULL,
  `dataHora` datetime DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeCamera` varchar(30) DEFAULT NULL,
  `nomeTecnico` varchar(100) DEFAULT NULL,
  `horaInicio` time DEFAULT NULL,
  `horaTermino` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id_3` (`id`),
  KEY `FK_PreventivaCameraTecnico_1` (`fk_Tecnico_id`),
  KEY `FK_PreventivaCameraTecnico_2` (`fk_PreventivaCamera_id`),
  CONSTRAINT `FK_PreventivaCameraTecnico_2` FOREIGN KEY (`fk_PreventivaCamera_id`) REFERENCES `preventivacamera` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preventivacameratecnico`
--

LOCK TABLES `preventivacameratecnico` WRITE;
/*!40000 ALTER TABLE `preventivacameratecnico` DISABLE KEYS */;
INSERT INTO `preventivacameratecnico` VALUES (1,4,'2024-04-28 20:45:22',1,'P90FIX003',NULL,NULL,NULL),(1,5,'2024-04-28 20:47:43',2,'P90FIX003',NULL,NULL,NULL),(1,6,'2024-04-28 20:48:31',3,'P90FIX003',NULL,NULL,NULL),(30,8,'2024-04-28 20:52:29',4,'P90FIX003',NULL,NULL,NULL),(30,9,'2024-04-28 20:55:54',5,'P90FIX003','Giulio Miguel Simão da Silva',NULL,NULL),(1,10,'2024-04-28 21:11:05',6,'P90FIX003','Giulio',NULL,NULL),(1,11,'2024-04-28 16:13:02',7,'P90FIX003','Giulio',NULL,NULL),(1,12,'2024-04-28 17:28:00',8,'P90FIX003','Giulio',NULL,NULL),(1,13,'2024-05-11 15:30:09',9,'P90FIX001','Giulio',NULL,NULL),(1,14,'2024-05-11 15:30:51',10,'P90FIX001','Giulio',NULL,NULL),(1,15,'2024-05-11 15:31:46',11,'P90FIX001','Giulio',NULL,NULL),(1,16,'2024-05-11 15:33:10',12,'P90FIX001','Giulio',NULL,NULL),(1,17,'2025-11-11 15:33:57',13,'P90FIX001','Giulio',NULL,NULL),(1,18,'2029-05-11 15:46:56',14,'P90FIX001','Giulio',NULL,NULL),(1,19,'2002-03-03 15:46:29',15,'P90FIX001','Giulio',NULL,NULL),(1,20,'2002-03-03 15:49:33',16,'P90FIX001','Giulio',NULL,NULL),(1,21,'2035-05-11 15:57:19',17,'P90FIX001','Giulio',NULL,NULL),(1,22,'2035-05-11 15:58:11',18,'P90FIX001','Giulio',NULL,NULL),(1,23,'2024-11-11 17:46:28',19,'P90FIX001','Giulio',NULL,NULL),(1,24,'2025-05-11 10:29:55',20,'P90FIX001','Giulio',NULL,NULL),(1,25,'2025-05-11 17:58:08',21,'P90FIX001','Giulio',NULL,NULL),(32,26,'2024-05-11 21:43:51',22,'P90FIX001','Ana Clara',NULL,NULL),(1,27,'2024-05-12 18:17:20',23,'123','Giulio',NULL,NULL),(1,28,'2024-05-12 18:35:33',24,'P90FIX005','Giulio',NULL,NULL),(1,30,'2024-05-12 18:39:48',25,'P90FIX007','Giulio','18:39:35','18:39:48'),(1,31,'2024-05-12 18:46:00',26,'P20FIX001','Giulio','18:45:53','18:46:00'),(1,32,'2024-05-12 18:48:07',27,'P20FIX002','Giulio','18:48:01','18:48:07'),(1,33,'2024-05-12 18:52:16',28,'P20FIX003','Giulio','18:52:10','18:52:16'),(1,34,'2024-05-12 18:54:27',29,'P20FIX004','Giulio','18:54:21','18:54:27'),(1,35,'2024-05-12 18:54:40',30,'P20FIX004','Giulio','18:54:21','18:54:40'),(1,36,'2024-05-12 19:02:15',31,'P20FIX006','Giulio','19:02:09','19:02:15'),(4,37,'2024-05-13 21:12:53',32,'teste123','Fabiano da Silva Santos Roberto','21:12:38','21:12:53'),(1,38,'2024-06-04 22:21:13',33,'P100FIX012','Giulio','22:20:58','22:21:13'),(1,39,'2024-06-16 04:44:17',34,'P100FIX013','Giulio','04:44:01','04:44:17');
/*!40000 ALTER TABLE `preventivacameratecnico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preventivatelevisao`
--

DROP TABLE IF EXISTS `preventivatelevisao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preventivatelevisao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tela` varchar(100) DEFAULT NULL,
  `cabeamento` varchar(100) DEFAULT NULL,
  `controles` varchar(100) DEFAULT NULL,
  `configuracao` varchar(100) DEFAULT NULL,
  `observacao` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preventivatelevisao`
--

LOCK TABLES `preventivatelevisao` WRITE;
/*!40000 ALTER TABLE `preventivatelevisao` DISABLE KEYS */;
INSERT INTO `preventivatelevisao` VALUES (1,'ok','ok','ok','ok','ok'),(2,'Ok','Ok','Ok','Ok','Preventiva realizada'),(3,'Ok','Ok','Ok','Ok','Preventiva realizada'),(4,'Ok','Ok','Ok','Ok','Preventiva realizada'),(5,'Ok','Ok','Ok','Ok','Preventiva realizada'),(6,'Ok','Ok','Ok','Ok','Preventiva realizada'),(7,' ',' ',' ',' ',' '),(8,' ',' ',' ',' ',' '),(9,' ',' ',' ',' ',' '),(10,' ',' ',' ',' ',' '),(11,' ',' ',' ',' ',' '),(12,' ',' ',' ',' ',' '),(13,' ',' ',' ',' ',' ');
/*!40000 ALTER TABLE `preventivatelevisao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preventivatelevisaotecnico`
--

DROP TABLE IF EXISTS `preventivatelevisaotecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preventivatelevisaotecnico` (
  `fk_Tecnico_id` int DEFAULT NULL,
  `fk_PreventivaTelevisao_id` int DEFAULT NULL,
  `dataHora` datetime DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeTecnico` varchar(100) DEFAULT NULL,
  `serialTv` varchar(100) DEFAULT NULL,
  `horaInicio` time DEFAULT NULL,
  `horaTermino` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK_PreventivaTelevisaoTecnico_1` (`fk_Tecnico_id`),
  KEY `FK_PreventivaTelevisaoTecnico_2` (`fk_PreventivaTelevisao_id`),
  CONSTRAINT `FK_PreventivaTelevisaoTecnico_1` FOREIGN KEY (`fk_Tecnico_id`) REFERENCES `tecnico` (`id`),
  CONSTRAINT `FK_PreventivaTelevisaoTecnico_2` FOREIGN KEY (`fk_PreventivaTelevisao_id`) REFERENCES `preventivatelevisao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preventivatelevisaotecnico`
--

LOCK TABLES `preventivatelevisaotecnico` WRITE;
/*!40000 ALTER TABLE `preventivatelevisaotecnico` DISABLE KEYS */;
INSERT INTO `preventivatelevisaotecnico` VALUES (1,4,'2024-04-28 17:24:13',1,'Giulio','123ABCD123',NULL,NULL),(1,5,'2024-04-28 17:26:40',2,'Giulio','123ABCD123',NULL,NULL),(1,6,'2024-04-28 17:27:39',3,'Giulio','123ABCD123',NULL,NULL),(1,7,'2024-05-12 18:16:49',4,'Giulio','123',NULL,NULL),(1,8,'2024-05-12 18:24:10',5,'Giulio','010WXYZ010','23:24:07','23:24:10'),(1,9,'2024-05-12 18:26:51',6,'Giulio','505CDEF505','23:26:47','18:26:51'),(1,10,'2024-05-12 18:30:33',7,'Giulio','323564577867','18:30:30','18:30:33'),(1,11,'2024-05-12 18:43:55',8,'Giulio','808OPQR808','18:43:52','18:43:55'),(1,12,'2024-05-12 18:51:04',9,'Giulio','909STUV909','18:51:01','18:51:04'),(1,13,'2024-05-12 19:02:46',10,'Giulio','121IJKL121','19:02:43','19:02:46');
/*!40000 ALTER TABLE `preventivatelevisaotecnico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecnico`
--

DROP TABLE IF EXISTS `tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tecnico` (
  `cargo` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `nivel` int DEFAULT NULL,
  `senha` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecnico`
--

LOCK TABLES `tecnico` WRITE;
/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
INSERT INTO `tecnico` VALUES ('Eletrotecnico','admin@naxsys.com.br','Giulio',1,1,'admin'),('Tecnico','carlos89@hotmail.com','Carlos Eduardo Souza Lima',5,1,'5678'),('Tecnico','ana_tec@yahoo.com','Ana Carolina Oliveira Santos',6,2,'9012'),('Tecnico','rodrigo_tec@gmail.com','Rodrigo dos Santos Sousa',10,1,'6789'),('Tecnico','maria_tec@hotmail.com','Maria Aparecida Lima Silva',11,2,'0123'),('Tecnico','joao_tec@yahoo.com','João da Silva Santos',12,0,'4567'),('Tecnico','gabriel_tec@hotmail.com','Gabriel Oliveira Santos',14,2,'2345'),('Tecnico','rafael_tec@yahoo.com','Rafael Lima Souza',15,0,'6789'),('Tecnico','fernanda_tec@gmail.com','Fernanda da Silva Oliveira',16,1,'0123'),('Tecnico','marcelo_tec@hotmail.com','Marcelo Almeida Costa',17,2,'4567'),('Tecnico','amanda_tec@yahoo.com','Amanda Pereira Lima',18,0,'8901'),('Tecnico','pedro_tec@gmail.com','Pedro Rodrigues Oliveira',19,1,'2345'),('Tecnico','luis_tec@yahoo.com','Luís Lima Alves',21,0,'0123'),('Tecnico','isabela_tec@gmail.com','Isabela Oliveira Silva',22,1,'4567'),('Tecnico','anderson_tec@hotmail.com','Anderson da Silva Souza',23,2,'8901'),('Eletrotecnico ','thomas@gmail.com','Thomas',24,1,''),('Tecnico ','lucasmoura@gmail.com','Lucas',25,1,''),('Eletrotecnico ','richard@gmail.com','Richard',26,1,''),('Eletrotecnico ','richard@gmail.com','Richard',27,1,''),('Eletrotecnico ','richard@gmail.com','Richard',28,1,''),('Eletrotecnio ','tombraider@gmail.com','Tombraider',29,1,'1234'),('Eletrotecnico ','ricardo@gmail.com','Ricardo',31,1,'1234'),('Chefa ','ancassis21@gmail.com','Ana Clara',32,1,'anaclara');
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `televisao`
--

DROP TABLE IF EXISTS `televisao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `televisao` (
  `serial` varchar(100) NOT NULL,
  `marca` varchar(20) DEFAULT NULL,
  `polegadas` varchar(5) DEFAULT NULL,
  `local` varchar(100) DEFAULT NULL,
  `dataInstalacao` date DEFAULT NULL,
  PRIMARY KEY (`serial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `televisao`
--

LOCK TABLES `televisao` WRITE;
/*!40000 ALTER TABLE `televisao` DISABLE KEYS */;
INSERT INTO `televisao` VALUES ('010WXYZ010','Sony','75','Bloco C',NULL),('121IJKL121','LG','45','P100',NULL),('123','123','123','123','0012-12-12'),('123  345 ',' ',' ',' ','0003-02-01'),('123 123 ','123','a','qualquer coisa','0012-12-12'),('12302020 ','LG','55','TESTEEEEE','2024-04-10'),('1234 ','a','a','qualquer coisa','0002-02-02'),('1234  ',' ',' ','qualquer coisa','0003-02-01'),('1234   2 ',' ',' ',' ','0003-02-01'),('1234 321','123','123','qualquer coisa','0012-12-12'),('123ABCD12333 ','LG','55','teste','2018-03-16'),('4343 ','LG','55','Predio 40','2024-04-05'),('45345 ','345345','123','qualquer coisa','0343-12-12'),('505CDEF505','Sony','70','Sala P90',NULL),('606GHIJ606','Panasonic','55','Board 90',NULL),('909STUV909','Samsung','32','Bloco C',NULL),('abc321','12','23','qualquer coisaa','2015-12-12');
/*!40000 ALTER TABLE `televisao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-16  8:37:34
